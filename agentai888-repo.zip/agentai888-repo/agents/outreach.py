"""
Outreach Agent — Sends personalized SMS + email via GHL API.
"""
import os, httpx
from loguru import logger
from anthropic import Anthropic

client = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
GHL_API_KEY  = os.getenv("GHL_API_KEY", "")
GHL_BASE_URL = os.getenv("GHL_BASE_URL", "https://services.leadconnectorhq.com")

class OutreachAgent:
    async def run(self, payload: dict):
        contact_id = payload.get("contact_id")
        name       = payload.get("name", "there")
        logger.info(f"📡 Outreach Agent running for {name}")

        message = await self._generate_message(payload)
        await self._send_sms(contact_id, message)
        await self._update_status(contact_id, "AgentAI888: Outreach Sent")
        await self._add_handoff_tag(contact_id, "ai-followup")
        logger.info(f"✅ Outreach complete for {contact_id}")

    async def _generate_message(self, payload: dict) -> str:
        prompt = f"""Write a short, personalized first-touch SMS (under 160 chars) for this lead.
Lead: {payload}
Rules: Use their name, be conversational, end with a question, NO sales pitch.
Respond with ONLY the SMS text."""

        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=200,
            messages=[{"role": "user", "content": prompt}]
        )
        return response.content[0].text.strip()

    async def _send_sms(self, contact_id: str, message: str):
        headers = {"Authorization": f"Bearer {GHL_API_KEY}", "Content-Type": "application/json"}
        async with httpx.AsyncClient() as c:
            try:
                await c.post(f"{GHL_BASE_URL}/conversations/messages", json={"contactId": contact_id, "type": "SMS", "message": message}, headers=headers, timeout=10)
            except Exception as e:
                logger.error(f"SMS send failed: {e}")

    async def _update_status(self, contact_id: str, status: str):
        headers = {"Authorization": f"Bearer {GHL_API_KEY}", "Content-Type": "application/json"}
        async with httpx.AsyncClient() as c:
            try:
                await c.put(f"{GHL_BASE_URL}/contacts/{contact_id}", json={"customField": {"ai_status": status}}, headers=headers, timeout=10)
            except Exception as e:
                logger.error(f"Status update failed: {e}")

    async def _add_handoff_tag(self, contact_id: str, tag: str):
        headers = {"Authorization": f"Bearer {GHL_API_KEY}", "Content-Type": "application/json"}
        async with httpx.AsyncClient() as c:
            try:
                await c.post(f"{GHL_BASE_URL}/contacts/{contact_id}/tags", json={"tags": [tag]}, headers=headers, timeout=10)
            except Exception as e:
                logger.error(f"Tag add failed: {e}")
