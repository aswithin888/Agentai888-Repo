"""
Lead Intel Agent — Enriches GHL contacts and assigns AI lead scores.
Writes score back to GHL and hands off to Outreach Agent via tag.
"""
import os
from loguru import logger
from anthropic import Anthropic

client = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
GHL_API_KEY     = os.getenv("GHL_API_KEY", "")
GHL_BASE_URL    = os.getenv("GHL_BASE_URL", "https://services.leadconnectorhq.com")

class LeadIntelAgent:
    async def run(self, payload: dict):
        contact_id = payload.get("contact_id")
        name       = payload.get("name", "Unknown")
        logger.info(f"🧠 Lead Intel running for {name} ({contact_id})")

        score = await self._score_lead(payload)
        payload["lead_score"] = score

        await self._write_back_to_ghl(contact_id, score)
        await self._add_handoff_tag(contact_id)
        logger.info(f"✅ Lead Intel complete — score={score} — handed off to Outreach")

    async def _score_lead(self, payload: dict) -> int:
        prompt = f"""Score this lead from 0-100 for sales readiness.
Lead data: {payload}
Respond with ONLY a number between 0 and 100. No explanation."""

        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=10,
            messages=[{"role": "user", "content": prompt}]
        )
        try:
            score = int(response.content[0].text.strip())
            return max(0, min(100, score))
        except (ValueError, IndexError):
            return 50

    async def _write_back_to_ghl(self, contact_id: str, score: int):
        import httpx
        headers = {"Authorization": f"Bearer {GHL_API_KEY}", "Content-Type": "application/json"}
        body    = {"customField": {"lead_score": score, "ai_status": f"AgentAI888: Scored {score}"}}
        async with httpx.AsyncClient() as client:
            try:
                await client.put(f"{GHL_BASE_URL}/contacts/{contact_id}", json=body, headers=headers, timeout=10)
            except Exception as e:
                logger.error(f"GHL write-back failed: {e}")

    async def _add_handoff_tag(self, contact_id: str):
        import httpx
        headers = {"Authorization": f"Bearer {GHL_API_KEY}", "Content-Type": "application/json"}
        async with httpx.AsyncClient() as client:
            try:
                await client.post(f"{GHL_BASE_URL}/contacts/{contact_id}/tags", json={"tags": ["ai-outreach"]}, headers=headers, timeout=10)
            except Exception as e:
                logger.error(f"Tag add failed: {e}")
