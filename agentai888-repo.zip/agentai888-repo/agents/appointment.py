"""Appointment Agent — Books discovery calls via GHL calendar API."""
import os, httpx
from loguru import logger

GHL_API_KEY     = os.getenv("GHL_API_KEY", "")
GHL_BASE_URL    = os.getenv("GHL_BASE_URL", "https://services.leadconnectorhq.com")
GHL_CALENDAR_ID = os.getenv("GHL_CALENDAR_ID", "")

class AppointmentAgent:
    async def run(self, payload: dict):
        contact_id = payload.get("contact_id")
        logger.info(f"📅 Appointment Agent running for {contact_id}")
        await self._move_pipeline(contact_id, "Appointment Booked")
        await self._send_booking_link(contact_id)
        await self._update_status(contact_id, "AgentAI888: Booking in Progress")
        await self._add_handoff_tag(contact_id, "ai-crm")
        logger.info(f"✅ Appointment flow triggered for {contact_id}")

    async def _move_pipeline(self, contact_id: str, stage: str):
        headers = {"Authorization": f"Bearer {GHL_API_KEY}", "Content-Type": "application/json"}
        async with httpx.AsyncClient() as c:
            try:
                await c.patch(f"{GHL_BASE_URL}/opportunities/contact/{contact_id}", json={"pipelineStageName": stage}, headers=headers, timeout=10)
            except Exception as e:
                logger.error(f"Pipeline move failed: {e}")

    async def _send_booking_link(self, contact_id: str):
        calendar_url = f"https://api.gohighlevel.com/v1/calendars/{GHL_CALENDAR_ID}/free-slots"
        booking_msg  = f"Here's a link to book a quick 20-minute call: {calendar_url}"
        headers = {"Authorization": f"Bearer {GHL_API_KEY}", "Content-Type": "application/json"}
        async with httpx.AsyncClient() as c:
            try:
                await c.post(f"{GHL_BASE_URL}/conversations/messages", json={"contactId": contact_id, "type": "SMS", "message": booking_msg}, headers=headers, timeout=10)
            except Exception as e:
                logger.error(f"Booking SMS failed: {e}")

    async def _update_status(self, contact_id: str, status: str):
        headers = {"Authorization": f"Bearer {GHL_API_KEY}", "Content-Type": "application/json"}
        async with httpx.AsyncClient() as c:
            try:
                await c.put(f"{GHL_BASE_URL}/contacts/{contact_id}", json={"customField": {"ai_status": status}}, headers=headers, timeout=10)
            except Exception as e:
                logger.error(f"Status update failed: {e}")

    async def _add_handoff_tag(self, contact_id: str, tag: str):
        headers = {"Authorization": f"Bearer {GHL_API_KEY}", "Content-Type": "application/json"}
        async with httpx.AsyncClient() as c:
            try:
                await c.post(f"{GHL_BASE_URL}/contacts/{contact_id}/tags", json={"tags": [tag]}, headers=headers, timeout=10)
            except Exception as e:
                logger.error(f"Tag add failed: {e}")
