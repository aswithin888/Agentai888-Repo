"""
AIONexus — Policy Engine + Hash-Chained Audit Ledger
Every agent action is logged. Policy rules block non-compliant outreach.
"""
import hashlib, json, os
from datetime import datetime
from loguru import logger

LEAD_SCORE_THRESHOLD = int(os.getenv("LEAD_SCORE_THRESHOLD", "50"))

# Policy rules — returns False to BLOCK, True to ALLOW
POLICY_RULES = {
    "outreach": lambda payload: payload.get("lead_score", 0) >= LEAD_SCORE_THRESHOLD,
    "appointment": lambda payload: payload.get("lead_score", 0) >= 60,
    "lead_intel": lambda payload: True,
    "followup": lambda payload: True,
    "crm": lambda payload: True,
    "browser": lambda payload: True,
}

class AIONexus:
    def __init__(self):
        self._ledger: list[dict] = []
        self._last_hash = "GENESIS"
        logger.info("🔐 AIONexus policy engine active")

    async def check_policy(self, agent_key: str, payload: dict) -> bool:
        rule = POLICY_RULES.get(agent_key)
        if rule is None:
            return True
        allowed = rule(payload)
        if not allowed:
            await self.log(
                agent_id=agent_key,
                action="Policy Block",
                contact_id=payload.get("contact_id", "unknown"),
                result=f"BLOCKED — lead_score={payload.get('lead_score', 0)} below threshold"
            )
        return allowed

    async def log(self, agent_id: str, action: str, contact_id: str, result: str):
        """Add a hash-chained entry to the audit ledger."""
        entry = {
            "id":         len(self._ledger) + 1,
            "ts":         datetime.utcnow().isoformat(),
            "agent_id":   agent_id,
            "action":     action,
            "contact_id": contact_id,
            "result":     result,
            "prev_hash":  self._last_hash,
        }
        entry_hash = hashlib.sha256(
            json.dumps(entry, sort_keys=True).encode()
        ).hexdigest()[:16]
        entry["hash"] = entry_hash
        self._last_hash = entry_hash
        self._ledger.append(entry)
        logger.info(f"📋 [{agent_id}] {action} — {contact_id} — {result}")

    async def get_recent_entries(self, limit: int = 25) -> list:
        return list(reversed(self._ledger))[:limit]
