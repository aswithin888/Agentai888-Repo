"""Follow-Up Agent — Day 1/3/7 sequences + SLA watch."""
import os, httpx
from loguru import logger

GHL_API_KEY  = os.getenv("GHL_API_KEY", "")
GHL_BASE_URL = os.getenv("GHL_BASE_URL", "https://services.leadconnectorhq.com")
SLA_HOURS    = int(os.getenv("SLA_HOURS", "48"))

class FollowUpAgent:
    async def run(self, payload: dict):
        contact_id = payload.get("contact_id")
        logger.info(f"🔁 Follow-Up Agent running for {contact_id}")
        await self._schedule_sequence(contact_id, payload)
        await self._update_status(contact_id, "AgentAI888: Follow-Up Sequence Active")
        logger.info(f"✅ Follow-Up sequence scheduled for {contact_id}")

    async def _schedule_sequence(self, contact_id: str, payload: dict):
        """
        In production: add contact to a GHL workflow or schedule
        delayed tasks via Redis queue for Day 1, 3, 7 touches.
        """
        headers = {"Authorization": f"Bearer {GHL_API_KEY}", "Content-Type": "application/json"}
        async with httpx.AsyncClient() as c:
            try:
                # Add to follow-up workflow in GHL
                await c.post(f"{GHL_BASE_URL}/contacts/{contact_id}/workflow", json={"workflowId": os.getenv("GHL_FOLLOWUP_WORKFLOW_ID", "")}, headers=headers, timeout=10)
            except Exception as e:
                logger.error(f"Follow-up workflow add failed: {e}")

    async def _update_status(self, contact_id: str, status: str):
        headers = {"Authorization": f"Bearer {GHL_API_KEY}", "Content-Type": "application/json"}
        async with httpx.AsyncClient() as c:
            try:
                await c.put(f"{GHL_BASE_URL}/contacts/{contact_id}", json={"customField": {"ai_status": status}}, headers=headers, timeout=10)
            except Exception as e:
                logger.error(f"Status update failed: {e}")
