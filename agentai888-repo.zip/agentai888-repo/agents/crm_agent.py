"""CRM Agent — Keeps GoHighLevel clean. Updates fields, notes, tags, pipeline."""
import os, httpx
from datetime import datetime
from loguru import logger

GHL_API_KEY  = os.getenv("GHL_API_KEY", "")
GHL_BASE_URL = os.getenv("GHL_BASE_URL", "https://services.leadconnectorhq.com")

class CRMAgent:
    async def run(self, payload: dict):
        contact_id = payload.get("contact_id")
        logger.info(f"🗂️  CRM Agent running for {contact_id}")
        await self._add_note(contact_id, payload)
        await self._update_fields(contact_id, payload)
        await self._add_final_tag(contact_id)
        logger.info(f"✅ CRM Agent complete for {contact_id}")

    async def _add_note(self, contact_id: str, payload: dict):
        note = (
            f"AI Workflow Completed — {datetime.utcnow().strftime('%Y-%m-%d %H:%M')} UTC\n"
            f"Lead Score: {payload.get('lead_score', 'N/A')}\n"
            f"Source: {payload.get('source', 'unknown')}\n"
            f"Pipeline: {payload.get('pipeline_stage', 'unknown')}\n"
            f"Processed by AgentAI888 — The Alleges Group Inc."
        )
        headers = {"Authorization": f"Bearer {GHL_API_KEY}", "Content-Type": "application/json"}
        async with httpx.AsyncClient() as c:
            try:
                await c.post(f"{GHL_BASE_URL}/contacts/{contact_id}/notes", json={"body": note}, headers=headers, timeout=10)
            except Exception as e:
                logger.error(f"Note add failed: {e}")

    async def _update_fields(self, contact_id: str, payload: dict):
        headers = {"Authorization": f"Bearer {GHL_API_KEY}", "Content-Type": "application/json"}
        body = {
            "customField": {
                "ai_status":     "AgentAI888: Complete",
                "last_ai_action": f"CRM Update {datetime.utcnow().strftime('%m/%d/%Y %H:%M')}",
                "lead_score":    payload.get("lead_score", 0)
            }
        }
        async with httpx.AsyncClient() as c:
            try:
                await c.put(f"{GHL_BASE_URL}/contacts/{contact_id}", json=body, headers=headers, timeout=10)
            except Exception as e:
                logger.error(f"Field update failed: {e}")

    async def _add_final_tag(self, contact_id: str):
        headers = {"Authorization": f"Bearer {GHL_API_KEY}", "Content-Type": "application/json"}
        async with httpx.AsyncClient() as c:
            try:
                await c.post(f"{GHL_BASE_URL}/contacts/{contact_id}/tags", json={"tags": ["ai-complete"]}, headers=headers, timeout=10)
            except Exception as e:
                logger.error(f"Final tag failed: {e}")
