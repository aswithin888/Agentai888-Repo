# AgentAI888 GHL MCP Server

> **The Alleges Group Inc.** — Plug GoHighLevel AI automation into any Claude-powered system in 2 minutes.

## What This Does

This MCP server exposes all AgentAI888 capabilities as tools any Claude agent can call:

| Tool | What it does |
|---|---|
| `ghl_send_sms` | Send personalized SMS via GHL |
| `ghl_score_lead` | Run Lead Intel Agent on a contact |
| `ghl_book_appointment` | Trigger Appointment Agent |
| `ghl_update_contact` | Update fields, stage, notes |
| `ghl_create_funnel` | Browser Agent builds a funnel |
| `ghl_buy_phone_number` | Browser Agent buys a GHL number |
| `ghl_create_workflow` | Browser Agent builds a workflow |
| `ghl_browser_task` | Any plain-English GHL task |
| `ghl_run_playbook` | Run a named pre-built playbook |
| `ghl_get_audit_log` | Pull recent audit entries |
| `ghl_system_status` | Check all agent statuses |

---

## Setup (2 minutes)

### 1. Add to Claude Desktop

Edit `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "agentai888-ghl": {
      "command": "python",
      "args": ["/path/to/agentai888-repo/mcp_server/server.py"],
      "env": {
        "AGENTAI_BASE_URL": "https://your-agentai888-server.com",
        "AGENTAI_MCP_KEY":  "your-api-key"
      }
    }
  }
}
```

Restart Claude Desktop. You'll see the AgentAI888 tools appear.

### 2. Use in Claude Projects

Once connected, Claude can use your GHL tools naturally:

> "Score this lead and send them a personalized SMS"
> → Claude calls `ghl_score_lead` then `ghl_send_sms` automatically

> "Create a funnel for my mortgage campaign with headline 'Get Pre-Approved Today'"
> → Claude calls `ghl_create_funnel` with the right parameters

> "Run the daily lead report"
> → Claude calls `ghl_run_playbook` with `daily_lead_report`

### 3. Add to Any FastAPI / LangChain / Custom Agent

```python
import anthropic

client = anthropic.Anthropic()

# Claude will automatically call your GHL tools when needed
response = client.beta.messages.create(
    model="claude-opus-4-5",
    max_tokens=1024,
    tools=agentai888_tools,  # from mcp_config.json
    messages=[{
        "role": "user",
        "content": "A new lead just came in: John Doe, 713-555-0100. Score him and send a personalized outreach SMS."
    }]
)
```

---

## Licensing

Contact **The Alleges Group Inc.** to license API access:

- **Developer Tier**: $99/month — 1,000 tool calls/month
- **Agency Tier**: $499/month — 10,000 tool calls/month  
- **Enterprise**: Custom pricing — unlimited + white label

---

## Support

support@allegesgroup.com
