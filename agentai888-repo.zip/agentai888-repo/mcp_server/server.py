"""
AgentAI888 MCP Server
Exposes all GHL automation capabilities as MCP tools that any
Claude-powered system or AI agent can call.

Install: pip install mcp httpx
Run:     python mcp_server/server.py
"""
import asyncio, os, json, httpx
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

# Your AgentAI888 server base URL
AGENTAI_BASE = os.getenv("AGENTAI_BASE_URL", "http://localhost:8000")
API_KEY      = os.getenv("AGENTAI_MCP_KEY", "")

app = Server("agentai888-ghl")

# ── All exposed tools ────────────────────────────────────────────
TOOLS = [
    Tool(
        name="ghl_send_sms",
        description="Send a personalized SMS to a GHL contact via the Outreach Agent",
        inputSchema={
            "type": "object",
            "properties": {
                "contact_id": {"type": "string", "description": "GHL contact ID"},
                "message":    {"type": "string", "description": "SMS message text (max 160 chars)"},
            },
            "required": ["contact_id", "message"]
        }
    ),
    Tool(
        name="ghl_score_lead",
        description="Run the Lead Intel Agent to enrich and score a GHL contact",
        inputSchema={
            "type": "object",
            "properties": {
                "contact_id": {"type": "string"},
                "name":       {"type": "string"},
                "email":      {"type": "string"},
                "phone":      {"type": "string"},
                "source":     {"type": "string"},
            },
            "required": ["contact_id"]
        }
    ),
    Tool(
        name="ghl_book_appointment",
        description="Trigger the Appointment Agent to book a discovery call for a contact",
        inputSchema={
            "type": "object",
            "properties": {
                "contact_id":   {"type": "string"},
                "contact_name": {"type": "string"},
            },
            "required": ["contact_id"]
        }
    ),
    Tool(
        name="ghl_update_contact",
        description="Update a GHL contact's custom fields, status, or pipeline stage",
        inputSchema={
            "type": "object",
            "properties": {
                "contact_id":     {"type": "string"},
                "pipeline_stage": {"type": "string", "description": "New pipeline stage name"},
                "ai_status":      {"type": "string", "description": "AI Status custom field value"},
                "lead_score":     {"type": "integer", "description": "Lead score 0-100"},
                "note":           {"type": "string", "description": "Note to add to contact record"},
            },
            "required": ["contact_id"]
        }
    ),
    Tool(
        name="ghl_create_funnel",
        description="Use the Browser Agent to create a new marketing funnel in GHL",
        inputSchema={
            "type": "object",
            "properties": {
                "funnel_name":  {"type": "string"},
                "headline":     {"type": "string"},
                "subheadline":  {"type": "string"},
                "cta_text":     {"type": "string"},
            },
            "required": ["funnel_name", "headline"]
        }
    ),
    Tool(
        name="ghl_buy_phone_number",
        description="Use the Browser Agent to purchase a GHL phone number for a campaign",
        inputSchema={
            "type": "object",
            "properties": {
                "area_code":     {"type": "string", "description": "3-digit area code e.g. 713"},
                "campaign_name": {"type": "string"},
            },
            "required": ["area_code", "campaign_name"]
        }
    ),
    Tool(
        name="ghl_create_workflow",
        description="Use the Browser Agent to build a new GHL automation workflow",
        inputSchema={
            "type": "object",
            "properties": {
                "workflow_name":    {"type": "string"},
                "sms_message":      {"type": "string"},
                "followup_message": {"type": "string"},
            },
            "required": ["workflow_name", "sms_message"]
        }
    ),
    Tool(
        name="ghl_browser_task",
        description="Send any plain-English task to the Browser Agent to execute in GHL",
        inputSchema={
            "type": "object",
            "properties": {
                "task":      {"type": "string", "description": "Plain English instruction for what to do in GHL"},
                "hitl_mode": {
                    "type": "string",
                    "enum": ["auto", "hitl", "always"],
                    "description": "auto=execute immediately, hitl=require approval for destructive actions, always=always require approval"
                },
            },
            "required": ["task"]
        }
    ),
    Tool(
        name="ghl_run_playbook",
        description="Run a named pre-built AgentAI888 playbook",
        inputSchema={
            "type": "object",
            "properties": {
                "playbook": {
                    "type": "string",
                    "enum": [
                        "buy_phone_number", "create_funnel", "create_funnel_with_phone",
                        "create_lead_workflow", "create_pipeline", "clean_stale_contacts",
                        "daily_lead_report", "weekly_performance_report",
                        "respond_to_inbox", "new_client_setup"
                    ],
                    "description": "Playbook key to run"
                },
                "variables": {
                    "type": "object",
                    "description": "Variables to fill into the playbook template"
                }
            },
            "required": ["playbook"]
        }
    ),
    Tool(
        name="ghl_get_audit_log",
        description="Retrieve the recent AgentAI888 audit ledger entries",
        inputSchema={
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "description": "Number of entries to return (default 10)"}
            }
        }
    ),
    Tool(
        name="ghl_system_status",
        description="Get the current status of all AgentAI888 agents",
        inputSchema={
            "type": "object",
            "properties": {}
        }
    ),
]

@app.list_tools()
async def list_tools() -> list[Tool]:
    return TOOLS

@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    headers = {"X-API-Key": API_KEY, "Content-Type": "application/json"}

    async with httpx.AsyncClient(base_url=AGENTAI_BASE, headers=headers, timeout=120) as client:

        # ── SMS ──────────────────────────────────────────────────
        if name == "ghl_send_sms":
            payload = {
                "contact_id": arguments["contact_id"],
                "type": "lead_created",
                "name": arguments.get("name", ""),
                "phone": arguments.get("phone", ""),
                "email": arguments.get("email", ""),
            }
            r = await client.post("/webhooks/ghl/lead-created", json=payload)
            return [TextContent(type="text", text=f"SMS queued for contact {arguments['contact_id']}. Status: {r.status_code}")]

        # ── SCORE LEAD ───────────────────────────────────────────
        elif name == "ghl_score_lead":
            r = await client.post("/webhooks/ghl/lead-created", json=arguments)
            return [TextContent(type="text", text=f"Lead Intel Agent processing contact {arguments['contact_id']}. Enrichment and scoring started.")]

        # ── BOOK APPOINTMENT ─────────────────────────────────────
        elif name == "ghl_book_appointment":
            payload = {**arguments, "tags": ["ai-book"], "type": "tag_ai-book"}
            r = await client.post("/webhooks/ghl/tag-added", json=payload)
            return [TextContent(type="text", text=f"Appointment Agent triggered for {arguments['contact_id']}.")]

        # ── UPDATE CONTACT ───────────────────────────────────────
        elif name == "ghl_update_contact":
            payload = {**arguments, "tags": ["ai-crm"], "type": "tag_ai-crm"}
            r = await client.post("/webhooks/ghl/tag-added", json=payload)
            return [TextContent(type="text", text=f"CRM Agent updating contact {arguments['contact_id']}.")]

        # ── BROWSER TASK ─────────────────────────────────────────
        elif name == "ghl_browser_task":
            r = await client.post("/agents/browser/task", json={
                "task":      arguments["task"],
                "hitl_mode": arguments.get("hitl_mode", "auto")
            })
            data = r.json()
            return [TextContent(type="text", text=f"Browser Agent task started. ID: {data.get('task_id')}. {data.get('message', '')}")]

        # ── CREATE FUNNEL ────────────────────────────────────────
        elif name == "ghl_create_funnel":
            from playbooks.playbook_library import build_instruction
            instruction = build_instruction("create_funnel", arguments)
            r = await client.post("/agents/browser/task", json={"task": instruction, "hitl_mode": "auto"})
            data = r.json()
            return [TextContent(type="text", text=f"Browser Agent creating funnel '{arguments['funnel_name']}'. Task ID: {data.get('task_id')}")]

        # ── BUY PHONE ────────────────────────────────────────────
        elif name == "ghl_buy_phone_number":
            from playbooks.playbook_library import build_instruction
            instruction = build_instruction("buy_phone_number", arguments)
            r = await client.post("/agents/browser/task", json={"task": instruction, "hitl_mode": "auto"})
            data = r.json()
            return [TextContent(type="text", text=f"Browser Agent buying phone number (area code {arguments['area_code']}). Task ID: {data.get('task_id')}")]

        # ── CREATE WORKFLOW ──────────────────────────────────────
        elif name == "ghl_create_workflow":
            from playbooks.playbook_library import build_instruction
            instruction = build_instruction("create_lead_workflow", arguments)
            r = await client.post("/agents/browser/task", json={"task": instruction, "hitl_mode": "auto"})
            data = r.json()
            return [TextContent(type="text", text=f"Browser Agent building workflow '{arguments['workflow_name']}'. Task ID: {data.get('task_id')}")]

        # ── RUN PLAYBOOK ─────────────────────────────────────────
        elif name == "ghl_run_playbook":
            r = await client.post("/api/playbooks/run", json={
                "playbook":  arguments["playbook"],
                "variables": arguments.get("variables", {})
            })
            data = r.json()
            return [TextContent(type="text", text=f"Playbook '{arguments['playbook']}' started. Task ID: {data.get('task_id')}")]

        # ── AUDIT LOG ────────────────────────────────────────────
        elif name == "ghl_get_audit_log":
            r = await client.get("/api/audit")
            entries = r.json().get("data", [])[:arguments.get("limit", 10)]
            lines = [f"[{e['ts']}] {e['agent_id']} — {e['action']} — {e['result']}" for e in entries]
            return [TextContent(type="text", text="Recent Audit Log:\n" + "\n".join(lines))]

        # ── SYSTEM STATUS ────────────────────────────────────────
        elif name == "ghl_system_status":
            r = await client.get("/api/agents")
            agents = r.json().get("data", [])
            lines = [f"• {a['name']} ({a['type']}) — {a['status'].upper()} — v{a['version']}" for a in agents]
            return [TextContent(type="text", text="AgentAI888 System Status:\n" + "\n".join(lines))]

        else:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]

async def main():
    async with stdio_server() as streams:
        await app.run(streams[0], streams[1], app.create_initialization_options())

if __name__ == "__main__":
    asyncio.run(main())
