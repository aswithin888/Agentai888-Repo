"""
Playbook Library — Pre-built Browser Agent instruction sets for GHL.
The Alleges Group Inc.

Each Playbook is a named, reusable task the Browser Agent can execute
on command or automatically via triggers/schedule.
"""

PLAYBOOKS = {

    # ── PHONE NUMBERS ────────────────────────────────────────────
    "buy_phone_number": {
        "name": "Buy GHL Phone Number",
        "description": "Purchase a new phone number in GHL and assign it to a campaign",
        "category": "phone",
        "requires_hitl": False,
        "trigger_tags": ["buy-phone-number"],
        "instruction": """
Go to GoHighLevel and buy a new phone number:
1. Click 'Settings' in the left sidebar
2. Click 'Phone Numbers'
3. Click '+ Add Number' or 'Buy Number'
4. Search for available numbers with the requested area code
5. Select the first available number
6. Give it a friendly name matching the campaign name provided
7. Click 'Buy' or 'Purchase'
8. Confirm the purchase
9. Once purchased, note the number and report back: 'Phone number purchased: [number]'
""",
        "variables": ["area_code", "campaign_name"]
    },

    # ── FUNNELS ──────────────────────────────────────────────────
    "create_funnel": {
        "name": "Create Marketing Funnel",
        "description": "Build a new lead capture funnel in GHL Sites",
        "category": "funnel",
        "requires_hitl": False,
        "trigger_tags": ["create-funnel"],
        "instruction": """
Go to GoHighLevel and create a new marketing funnel:
1. Click 'Sites' in the left sidebar
2. Click 'Funnels'
3. Click '+ New Funnel'
4. Name the funnel: {funnel_name}
5. Select a template — choose the Lead Generation or Opt-In template
6. On the first page (opt-in page):
   - Update the main headline to: {headline}
   - Update the subheadline to: {subheadline}
   - Update the CTA button text to: {cta_text}
7. On the thank you page: update the confirmation message
8. Click 'Save' on each page
9. Click 'Publish' to make the funnel live
10. Copy the funnel URL and report back: 'Funnel created and live at: [URL]'
""",
        "variables": ["funnel_name", "headline", "subheadline", "cta_text"]
    },

    "create_funnel_with_phone": {
        "name": "Create Funnel + Buy Phone Number",
        "description": "Full campaign setup — phone number + funnel in one shot",
        "category": "campaign",
        "requires_hitl": False,
        "trigger_tags": ["full-campaign-setup"],
        "instruction": """
Complete full campaign setup in GoHighLevel:

PART 1 — Buy Phone Number:
1. Go to Settings → Phone Numbers → Buy Number
2. Search area code: {area_code}
3. Purchase first available number
4. Name it: {campaign_name} Line

PART 2 — Create Funnel:
1. Go to Sites → Funnels → New Funnel
2. Name it: {campaign_name} Funnel
3. Select Lead Generation template
4. Update headline: {headline}
5. Update CTA: {cta_text}
6. Save and Publish

PART 3 — Link Phone to Funnel:
1. Go to the funnel settings
2. Under 'Tracking', add the purchased phone number
3. Save

Report back: 'Campaign setup complete. Phone: [number]. Funnel URL: [url]'
""",
        "variables": ["campaign_name", "area_code", "headline", "cta_text"]
    },

    # ── WORKFLOWS ────────────────────────────────────────────────
    "create_lead_workflow": {
        "name": "Create Lead Capture Workflow",
        "description": "Build a GHL automation workflow for new leads",
        "category": "workflow",
        "requires_hitl": False,
        "trigger_tags": ["create-workflow"],
        "instruction": """
Go to GoHighLevel and create a new automation workflow:
1. Click 'Automation' in the left sidebar
2. Click 'Workflows'
3. Click '+ New Workflow' → Start from Scratch
4. Name it: {workflow_name}
5. Set trigger: 'Contact Created' OR 'Form Submitted' (choose based on campaign type)
6. Add Action: 'Send SMS' — message: '{sms_message}'
   Set delay: Immediately (0 minutes)
7. Add Action: 'Add Tag' — tag: 'ai-outreach'
8. Add Action: 'Wait' — 3 days
9. Add Action: 'Send Email' — subject: 'Following up...' body: '{followup_message}'
10. Add Action: 'Add Tag' — tag: 'ai-followup'
11. Click 'Save' then toggle to 'Published'
Report back: 'Workflow "{workflow_name}" created and published'
""",
        "variables": ["workflow_name", "sms_message", "followup_message"]
    },

    "create_sms_blast_workflow": {
        "name": "Create SMS Blast Workflow",
        "description": "Set up a one-time SMS blast to a contact segment",
        "category": "workflow",
        "requires_hitl": True,
        "trigger_tags": ["sms-blast"],
        "instruction": """
Create an SMS broadcast campaign in GoHighLevel:
1. Go to 'Marketing' → 'Emails' (or 'SMS' tab)
2. Click '+ New Campaign' or '+ New Broadcast'
3. Select 'SMS' as channel
4. Name the campaign: {campaign_name}
5. Select recipients: contacts with tag '{target_tag}'
6. Message: {sms_message}
7. Schedule: {send_time} (or Send Now)
8. Review the recipient count before sending
9. PAUSE HERE — report the recipient count and message preview before proceeding
   Wait for human confirmation before clicking Send
""",
        "variables": ["campaign_name", "target_tag", "sms_message", "send_time"]
    },

    # ── PIPELINES ────────────────────────────────────────────────
    "create_pipeline": {
        "name": "Create New Pipeline",
        "description": "Build a custom sales pipeline with stages in GHL",
        "category": "pipeline",
        "requires_hitl": False,
        "trigger_tags": ["create-pipeline"],
        "instruction": """
Create a new pipeline in GoHighLevel:
1. Go to 'CRM' or 'Opportunities' in the left sidebar
2. Click on the pipeline dropdown at the top
3. Click 'Add Pipeline' or the settings/gear icon
4. Name the pipeline: {pipeline_name}
5. Add these stages in order: {stages}
   (Click '+ Add Stage' for each one)
6. Set stage colors — use gold/yellow for early stages, green for closed
7. Click 'Save'
Report back: 'Pipeline "{pipeline_name}" created with {stage_count} stages'
""",
        "variables": ["pipeline_name", "stages"]
    },

    # ── CONTACTS ─────────────────────────────────────────────────
    "clean_stale_contacts": {
        "name": "Clean Stale Contacts",
        "description": "Find and tag contacts stuck in pipeline for 30+ days",
        "category": "crm",
        "requires_hitl": False,
        "trigger_tags": ["clean-contacts"],
        "schedule": "weekly",
        "instruction": """
Audit GoHighLevel for stale contacts:
1. Go to 'CRM' → 'Contacts'
2. Filter by: Last Activity more than 30 days ago
3. For each contact found:
   - Add tag: 'needs-review'
   - Add note: 'Flagged by AgentAI888 — no activity 30+ days'
4. Go to pipeline view — find any contacts stuck in the same stage for 14+ days
5. Add tag 'stale-pipeline' to those contacts
6. Generate a summary: how many contacts flagged, which stages have the most stale leads
Report back with the full summary
""",
        "variables": []
    },

    # ── REPORTING ────────────────────────────────────────────────
    "daily_lead_report": {
        "name": "Daily Lead Report",
        "description": "Pull overnight lead activity and summarize",
        "category": "reporting",
        "requires_hitl": False,
        "trigger_tags": [],
        "schedule": "daily_7am",
        "instruction": """
Pull the daily lead report from GoHighLevel:
1. Go to 'Reporting' or 'Dashboard' in GHL
2. Set date range to: Today (or last 24 hours)
3. Note and record:
   - Total new contacts added
   - Total appointments booked
   - Total messages sent (SMS + Email)
   - Pipeline stage distribution (how many in each stage)
   - Any contacts with SLA alerts (no response in 48h)
4. Take a screenshot of the reporting dashboard
5. Format a clean summary report with all the above numbers
Report back with the full summary in a clean format
""",
        "variables": []
    },

    "weekly_performance_report": {
        "name": "Weekly Performance Report",
        "description": "Full week performance summary from GHL",
        "category": "reporting",
        "requires_hitl": False,
        "trigger_tags": [],
        "schedule": "monday_8am",
        "instruction": """
Pull the weekly performance report from GoHighLevel:
1. Go to Reporting → set date range to last 7 days
2. Record all key metrics:
   - New leads this week vs last week
   - Appointments booked
   - Show rate (appointments completed / booked)
   - Deals closed / revenue
   - Top lead sources
   - Response time averages
   - Messages sent (SMS + email breakdown)
3. Check for any workflow errors or failed automations
4. List any contacts flagged with 'needs-review' or 'stale-pipeline' tags
5. Format as a professional weekly summary
Report back with the complete weekly report
""",
        "variables": []
    },

    # ── CLIENT ONBOARDING ────────────────────────────────────────
    "new_client_setup": {
        "name": "New Client Full Setup",
        "description": "Complete GHL sub-account configuration for a new client",
        "category": "onboarding",
        "requires_hitl": True,
        "trigger_tags": ["new-client-setup"],
        "instruction": """
Set up a complete GHL configuration for a new client:

1. PIPELINE — Create pipeline named '{client_name} Pipeline' with stages:
   New Lead → Contacted → Qualified → Appointment Booked → Closed Won → Closed Lost

2. CUSTOM FIELDS — Add these fields to contacts:
   - Lead Score (number)
   - AI Status (text)
   - Last AI Action (text)
   - Client Source (text)

3. PHONE NUMBER — Buy a local number with area code {area_code}
   Name it: {client_name} Main Line

4. FUNNEL — Create lead capture funnel:
   Name: {client_name} Lead Funnel
   Headline: {headline}
   CTA: Get Started Today

5. WORKFLOW — Create main automation:
   Name: {client_name} — AgentAI888 Lead Flow
   Trigger: Contact Created
   Action: Add tag 'ai-outreach'
   Publish the workflow

6. TEAM — Add note to sub-account: 'Configured by AgentAI888 — The Alleges Group Inc.'

Pause after each major section and confirm before proceeding.
Report back with a complete setup checklist when done.
""",
        "variables": ["client_name", "area_code", "headline"]
    },

    # ── INBOX MANAGEMENT ─────────────────────────────────────────
    "respond_to_inbox": {
        "name": "Respond to Unread Inbox Messages",
        "description": "Read and respond to GHL conversations older than 4 hours",
        "category": "inbox",
        "requires_hitl": False,
        "trigger_tags": [],
        "schedule": "every_4_hours",
        "instruction": """
Check and respond to unread messages in GoHighLevel inbox:
1. Go to 'Conversations' in the left sidebar
2. Filter by: Unread, sorted by oldest first
3. For each unread conversation older than 4 hours:
   a. Read the full conversation history
   b. Understand what the contact is asking or saying
   c. Write a professional, helpful response appropriate to their message
   d. Send the response
   e. If the conversation requires human judgment (complaints, legal, pricing negotiations)
      — add tag 'needs-human' and skip responding
4. Count how many messages were responded to vs flagged for human review
Report back: 'Responded to X messages. Flagged Y for human review.'
""",
        "variables": []
    },
}

def get_playbook(name: str) -> dict | None:
    """Retrieve a playbook by key name."""
    return PLAYBOOKS.get(name)

def list_playbooks(category: str = None) -> list[dict]:
    """List all playbooks, optionally filtered by category."""
    books = []
    for key, pb in PLAYBOOKS.items():
        if category is None or pb.get("category") == category:
            books.append({
                "key":          key,
                "name":         pb["name"],
                "description":  pb["description"],
                "category":     pb["category"],
                "requires_hitl":pb["requires_hitl"],
                "variables":    pb["variables"],
                "schedule":     pb.get("schedule"),
                "trigger_tags": pb.get("trigger_tags", []),
            })
    return books

def get_categories() -> list[str]:
    return list(set(pb["category"] for pb in PLAYBOOKS.values()))

def build_instruction(playbook_key: str, variables: dict) -> str:
    """Fill in a playbook's instruction template with provided variables."""
    pb = get_playbook(playbook_key)
    if not pb:
        raise ValueError(f"Playbook '{playbook_key}' not found")
    instruction = pb["instruction"]
    for key, value in variables.items():
        instruction = instruction.replace(f"{{{key}}}", str(value))
    return instruction.strip()
