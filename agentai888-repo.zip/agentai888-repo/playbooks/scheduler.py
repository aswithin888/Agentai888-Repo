"""
Playbook Scheduler — Runs playbooks automatically on a timer.
Uses APScheduler. Add 'apscheduler' to requirements.txt.
"""
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from loguru import logger
from datetime import datetime

from playbooks.playbook_library import PLAYBOOKS, build_instruction

class PlaybookScheduler:
    def __init__(self, browser_agent, hitl_manager, aionexus):
        self.scheduler     = AsyncIOScheduler()
        self.browser       = browser_agent
        self.hitl          = hitl_manager
        self.aionexus      = aionexus

    def start(self):
        """Register all scheduled playbooks and start the scheduler."""

        # Daily lead report — every day at 7am
        self.scheduler.add_job(
            self._run_playbook,
            CronTrigger(hour=7, minute=0),
            args=["daily_lead_report", {}],
            id="daily_lead_report",
            name="Daily Lead Report"
        )

        # Weekly performance report — every Monday at 8am
        self.scheduler.add_job(
            self._run_playbook,
            CronTrigger(day_of_week="mon", hour=8, minute=0),
            args=["weekly_performance_report", {}],
            id="weekly_performance_report",
            name="Weekly Performance Report"
        )

        # Clean stale contacts — every Sunday at 6am
        self.scheduler.add_job(
            self._run_playbook,
            CronTrigger(day_of_week="sun", hour=6, minute=0),
            args=["clean_stale_contacts", {}],
            id="clean_stale_contacts",
            name="Clean Stale Contacts"
        )

        # Respond to inbox — every 4 hours
        self.scheduler.add_job(
            self._run_playbook,
            CronTrigger(hour="*/4", minute=30),
            args=["respond_to_inbox", {}],
            id="respond_to_inbox",
            name="Inbox Response"
        )

        self.scheduler.start()
        logger.info("⏰ Playbook Scheduler started — 4 scheduled playbooks active")

    async def _run_playbook(self, playbook_key: str, variables: dict):
        """Execute a scheduled playbook via the Browser Agent."""
        import uuid
        task_id = f"scheduled-{playbook_key}-{uuid.uuid4().hex[:6]}"
        instruction = build_instruction(playbook_key, variables)

        pb = PLAYBOOKS.get(playbook_key, {})
        hitl_mode = "hitl" if pb.get("requires_hitl") else "auto"

        logger.info(f"⏰ Scheduled playbook firing: {playbook_key} [{task_id}]")
        await self.aionexus.log(
            agent_id="scheduler",
            action=f"Scheduled Playbook: {playbook_key}",
            contact_id="system",
            result="TRIGGERED"
        )

        await self.browser.execute_task(
            task_id=task_id,
            task=instruction,
            hitl_mode=hitl_mode,
            hitl_manager=self.hitl,
            aionexus=self.aionexus
        )

    def stop(self):
        self.scheduler.shutdown()
        logger.info("⏰ Playbook Scheduler stopped")
