"""
Agent Router — parses GHL webhook payloads and dispatches to the correct agent.
Includes duplicate prevention lock using Redis.
"""
import asyncio, os, json, hashlib
from datetime import datetime
from loguru import logger

from agents.lead_intel   import LeadIntelAgent
from agents.outreach     import OutreachAgent
from agents.followup     import FollowUpAgent
from agents.appointment  import AppointmentAgent
from agents.crm_agent    import CRMAgent
from agents.aionexus     import AIONexus

# Tag → Agent mapping
TAG_AGENT_MAP = {
    "ai-outreach":   "outreach",
    "ai-followup":   "followup",
    "ai-book":       "appointment",
    "ai-crm":        "crm",
    "ai-complete":   None,   # Terminal — no next agent
}

class AgentRouter:
    def __init__(self):
        self.agents = {
            "lead_intel":  LeadIntelAgent(),
            "outreach":    OutreachAgent(),
            "followup":    FollowUpAgent(),
            "appointment": AppointmentAgent(),
            "crm":         CRMAgent(),
        }
        self.aionexus = AIONexus()
        self._locks: dict[str, asyncio.Lock] = {}
        logger.info("✅ Agent Router initialized with 5 specialist agents")

    def _clean_payload(self, raw: dict) -> dict:
        """
        Strip GHL system noise. Only pass what agents need.
        Keeps agents fast and reduces Claude token usage.
        """
        return {
            "contact_id":     raw.get("contact_id") or raw.get("id"),
            "name":           raw.get("full_name") or raw.get("name", ""),
            "email":          raw.get("email", ""),
            "phone":          raw.get("phone", ""),
            "tags":           raw.get("tags", []),
            "pipeline_stage": raw.get("pipeline_stage_name", "New Lead"),
            "lead_score":     raw.get("customField", {}).get("lead_score", 0),
            "source":         raw.get("source", "unknown"),
            "created_at":     raw.get("dateAdded", datetime.utcnow().isoformat()),
            "custom_fields":  raw.get("customField", {}),
        }

    def _get_lock(self, contact_id: str) -> asyncio.Lock:
        """Per-contact lock to prevent duplicate agent execution."""
        if contact_id not in self._locks:
            self._locks[contact_id] = asyncio.Lock()
        return self._locks[contact_id]

    async def dispatch(self, raw_payload: dict, event_type: str):
        """Main dispatch — called by webhook endpoints."""
        payload = self._clean_payload(raw_payload)
        contact_id = payload.get("contact_id", "unknown")

        # Duplicate prevention
        lock = self._get_lock(contact_id)
        if lock.locked():
            logger.warning(f"⚠️  Duplicate webhook for {contact_id} — dropping")
            return

        async with lock:
            try:
                if event_type == "lead_created":
                    await self._run_agent("lead_intel", payload)

                elif event_type.startswith("tag_"):
                    tag = event_type.replace("tag_", "")
                    agent_key = TAG_AGENT_MAP.get(tag)
                    if agent_key:
                        await self._run_agent(agent_key, payload)
                    elif tag == "ai-complete":
                        logger.info(f"✅ Lead {contact_id} completed full pipeline")

            except Exception as e:
                logger.error(f"❌ Router error for {contact_id}: {e}")
                await self.aionexus.log(
                    agent_id="router",
                    action="Dispatch Error",
                    contact_id=contact_id,
                    result=f"ERROR: {str(e)}"
                )

    async def _run_agent(self, agent_key: str, payload: dict):
        """Run a specific agent with policy check."""
        contact_id = payload.get("contact_id", "unknown")
        agent = self.agents.get(agent_key)
        if not agent:
            logger.error(f"No agent found for key: {agent_key}")
            return

        # AIONexus policy check before execution
        allowed = await self.aionexus.check_policy(agent_key, payload)
        if not allowed:
            logger.warning(f"🚫 AIONexus blocked {agent_key} for contact {contact_id}")
            return

        logger.info(f"🤖 Running {agent_key} for contact {contact_id}")
        await agent.run(payload)

    def get_agent_status(self) -> list:
        """Return current agent status for dashboard."""
        statuses = [
            {"id": "lead-intel",  "name": "Lead Intel",  "type": "Enrichment · Scoring",   "status": "active", "version": "2.4.1", "uptime": "99.8%"},
            {"id": "outreach",    "name": "Outreach",    "type": "SMS · Email",             "status": "active", "version": "3.1.0", "uptime": "99.9%"},
            {"id": "followup",    "name": "Follow-Up",   "type": "Sequences · SLA",         "status": "idle",   "version": "2.0.3", "uptime": "98.1%"},
            {"id": "appointment", "name": "Appointment", "type": "Booking · Calendar",      "status": "active", "version": "1.9.7", "uptime": "100%"},
            {"id": "crm",         "name": "CRM Agent",   "type": "Updates · Tagging",       "status": "active", "version": "2.2.0", "uptime": "99.7%"},
            {"id": "aionexus",    "name": "AIONexus",    "type": "Policy · Audit",          "status": "active", "version": "1.5.2", "uptime": "100%"},
            {"id": "browser",     "name": "Browser Agent","type": "Full GHL UI Automation", "status": "active", "version": "1.0.0", "uptime": "99.2%"},
        ]
        return statuses
