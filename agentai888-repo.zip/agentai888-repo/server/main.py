"""
AgentAI888 × GoHighLevel — FastAPI Server
The Alleges Group Inc.
"""
from fastapi import FastAPI, Request, HTTPException, BackgroundTasks
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from loguru import logger
import os, uuid
from datetime import datetime

from router.agent_router import AgentRouter
from browser_agent.browser_agent import BrowserAgent
from browser_agent.hitl import HITLManager
from agents.aionexus import AIONexus
from playbooks.playbook_library import list_playbooks, get_playbook, build_instruction, PLAYBOOKS
from playbooks.scheduler import PlaybookScheduler
from interfaces.sms_interface import SMSInterface
from interfaces.slack_interface import SlackInterface

# ── App lifecycle ────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🚀 AgentAI888 starting up...")
    app.state.router    = AgentRouter()
    app.state.browser   = BrowserAgent()
    app.state.hitl      = HITLManager()
    app.state.aionexus  = AIONexus()
    app.state.sms       = SMSInterface(app.state.browser, app.state.hitl, app.state.aionexus)
    app.state.slack     = SlackInterface(app.state.browser, app.state.hitl, app.state.aionexus)
    app.state.scheduler = PlaybookScheduler(app.state.browser, app.state.hitl, app.state.aionexus)
    app.state.scheduler.start()
    yield
    logger.info("🛑 AgentAI888 shutting down...")
    app.state.scheduler.stop()
    await app.state.browser.close()

app = FastAPI(
    title="AgentAI888 AI Workforce",
    description="The Alleges Group Inc. — Autonomous GHL Revenue Engine",
    version="1.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve dashboard
app.mount("/static", StaticFiles(directory="dashboard"), name="static")

@app.get("/")
async def serve_dashboard():
    return FileResponse("dashboard/index.html")

# ════════════════════════════════════════════════════════════════
#  WEBHOOK ENDPOINTS — GHL fires these
# ════════════════════════════════════════════════════════════════

@app.post("/webhooks/ghl/lead-created")
async def ghl_lead_created(request: Request, background_tasks: BackgroundTasks):
    """Main entry point. GHL fires this when a new contact is created."""
    payload = await request.json()
    logger.info(f"📥 Lead webhook received: {payload.get('contact_id', 'unknown')}")
    background_tasks.add_task(request.app.state.router.dispatch, payload, "lead_created")
    return {"status": "received", "ts": datetime.utcnow().isoformat()}

@app.post("/webhooks/ghl/tag-added")
async def ghl_tag_added(request: Request, background_tasks: BackgroundTasks):
    """GHL fires this when a tag is added — drives agent handoffs."""
    payload = await request.json()
    tag = payload.get("tag", "")
    logger.info(f"🏷️  Tag added: {tag} on contact {payload.get('contact_id')}")
    background_tasks.add_task(request.app.state.router.dispatch, payload, f"tag_{tag}")
    return {"status": "received"}

@app.post("/webhooks/ghl/stage-changed")
async def ghl_stage_changed(request: Request, background_tasks: BackgroundTasks):
    """GHL fires this when a pipeline stage changes."""
    payload = await request.json()
    background_tasks.add_task(request.app.state.router.dispatch, payload, "stage_changed")
    return {"status": "received"}

@app.post("/webhooks/deploy")
async def deploy_agent(request: Request):
    """Dashboard Deploy button hits this endpoint."""
    body = await request.json()
    agent_id = body.get("agentId", "unknown")
    agent_name = body.get("agentName", "Unknown Agent")
    logger.info(f"⬆️  Deploy triggered for {agent_name}")
    await request.app.state.aionexus.log(
        agent_id=agent_id,
        action="Deploy Triggered",
        contact_id="dashboard",
        result="OK"
    )
    return {"success": True, "message": f'Agent "{agent_name}" deploy triggered'}

# ════════════════════════════════════════════════════════════════
#  BROWSER AGENT ENDPOINTS
# ════════════════════════════════════════════════════════════════

@app.post("/agents/browser/task")
async def browser_task(request: Request, background_tasks: BackgroundTasks):
    """Assign a plain-English task to the Browser Agent."""
    body = await request.json()
    task = body.get("task", "").strip()
    hitl_mode = body.get("hitl_mode", "always")

    if not task:
        raise HTTPException(status_code=400, detail="Task description is required")

    task_id = str(uuid.uuid4())[:8]
    logger.info(f"🖥️  Browser task [{task_id}]: {task[:80]}")

    background_tasks.add_task(
        request.app.state.browser.execute_task,
        task_id=task_id,
        task=task,
        hitl_mode=hitl_mode,
        hitl_manager=request.app.state.hitl,
        aionexus=request.app.state.aionexus
    )

    return {
        "success": True,
        "task_id": task_id,
        "message": "Browser Agent is logging into GHL and starting your task",
        "ts": datetime.utcnow().isoformat()
    }

@app.get("/agents/browser/status/{task_id}")
async def browser_task_status(task_id: str, request: Request):
    """Poll for browser task completion status."""
    status = await request.app.state.browser.get_task_status(task_id)
    return status

@app.post("/agents/browser/hitl/approve/{hitl_id}")
async def hitl_approve(hitl_id: str, request: Request):
    """Human approves a pending HITL action."""
    logger.info(f"✅ HITL approved: {hitl_id}")
    result = await request.app.state.hitl.approve(hitl_id)
    return {"approved": True, "hitl_id": hitl_id, "result": result}

@app.post("/agents/browser/hitl/reject/{hitl_id}")
async def hitl_reject(hitl_id: str, request: Request):
    """Human rejects a pending HITL action."""
    logger.info(f"❌ HITL rejected: {hitl_id}")
    result = await request.app.state.hitl.reject(hitl_id)
    return {"rejected": True, "hitl_id": hitl_id, "result": result}

@app.post("/agents/browser/funnel")
async def build_funnel(request: Request, background_tasks: BackgroundTasks):
    """
    Build an industry-specific funnel from a plain-English command.
    The Funnel Intelligence Engine detects the industry and generates
    the complete blueprint, then the Browser Agent builds it in GHL.
    """
    from browser_agent.funnel_intelligence import process_funnel_command
    body    = await request.json()
    command = body.get("command", "").strip()
    if not command:
        raise HTTPException(status_code=400, detail="Funnel command required")

    import uuid
    task_id = f"funnel-{uuid.uuid4().hex[:8]}"
    logger.info(f"🏗️  Funnel command [{task_id}]: {command[:80]}")

    # Full pipeline — understand command, generate blueprint, build instruction
    result = await process_funnel_command(command)

    # If agent needs clarification
    if result["status"] == "needs_clarification":
        return {
            "success": False,
            "needs_clarification": True,
            "question": result["clarification_question"],
            "task_id": task_id
        }

    logger.info(f"🎨 Blueprint ready — Industry: {result['industry']} — Funnel: {result['funnel_name']}")

    background_tasks.add_task(
        request.app.state.browser.execute_task,
        task_id=task_id,
        task=result["browser_instruction"],
        hitl_mode="auto",
        hitl_manager=request.app.state.hitl,
        aionexus=request.app.state.aionexus
    )

    return {
        "success":   True,
        "task_id":   task_id,
        "industry":  result["industry"],
        "funnel_name": result["funnel_name"],
        "summary":   result["summary"],
        "blueprint": result["blueprint"],
        "message":   f"Browser Agent building {result['industry']} funnel: {result['funnel_name']}"
    }

@app.get("/agents/browser/hitl/queue")
async def hitl_queue(request: Request):
    """Get all pending HITL approvals."""
    queue = await request.app.state.hitl.get_queue()
    return {"queue": queue, "count": len(queue)}

# ════════════════════════════════════════════════════════════════
#  DATA ENDPOINTS — Dashboard polls these
# ════════════════════════════════════════════════════════════════

@app.get("/api/agents")
async def get_agents(request: Request):
    return JSONResponse({"data": request.app.state.router.get_agent_status()})

@app.get("/api/audit")
async def get_audit(request: Request):
    entries = await request.app.state.aionexus.get_recent_entries(limit=25)
    return JSONResponse({"data": entries})

@app.get("/api/kpi")
async def get_kpi():
    from random import randint
    return JSONResponse({
        "kpi": {
            "leadsToday":   randint(44, 52),
            "apptBooked":   randint(10, 15),
            "messagesSent": randint(275, 295),
            "slaAlerts":    randint(1, 5)
        },
        "pipeline": [
            {"name": "New Lead",    "count": randint(20, 26), "color": "#C9A84C"},
            {"name": "Contacted",   "count": randint(15, 21), "color": "#4A8EE8"},
            {"name": "Qualified",   "count": randint(9,  14), "color": "#8B5CF6"},
            {"name": "Appt Booked", "count": randint(10, 14), "color": "#2ECC8A"},
            {"name": "Closed",      "count": randint(3,  7),  "color": "#2ECC8A"},
        ]
    })

# ════════════════════════════════════════════════════════════════
#  PLAYBOOK ENDPOINTS
# ════════════════════════════════════════════════════════════════

@app.get("/api/playbooks")
async def get_playbooks(category: str = None):
    """List all available playbooks."""
    return {"playbooks": list_playbooks(category), "count": len(list_playbooks(category))}

@app.post("/api/playbooks/run")
async def run_playbook(request: Request, background_tasks: BackgroundTasks):
    """Run a named playbook with optional variables."""
    body         = await request.json()
    playbook_key = body.get("playbook", "").strip()
    variables    = body.get("variables", {})

    if playbook_key not in PLAYBOOKS:
        raise HTTPException(status_code=404, detail=f"Playbook ''{playbook_key}'' not found")

    pb          = PLAYBOOKS[playbook_key]
    instruction = build_instruction(playbook_key, variables)
    hitl_mode   = "hitl" if pb.get("requires_hitl") else "auto"
    import uuid
    task_id = f"pb-{uuid.uuid4().hex[:8]}"

    background_tasks.add_task(
        request.app.state.browser.execute_task,
        task_id=task_id,
        task=instruction,
        hitl_mode=hitl_mode,
        hitl_manager=request.app.state.hitl,
        aionexus=request.app.state.aionexus
    )

    return {"success": True, "task_id": task_id, "playbook": playbook_key, "message": f"Running: {pb['name']}"}

# ════════════════════════════════════════════════════════════════
#  INTERFACE ENDPOINTS — SMS + Slack
# ════════════════════════════════════════════════════════════════

@app.post("/interfaces/sms")
async def sms_incoming(request: Request):
    """Twilio SMS webhook — command Browser Agent by text."""
    from fastapi.responses import Response
    twiml = await request.app.state.sms.handle_incoming(request)
    return Response(content=twiml, media_type="application/xml")

@app.post("/interfaces/slack")
async def slack_command(request: Request):
    """Slack slash command — /ghl [instruction]."""
    result = await request.app.state.slack.handle_slash_command(request)
    return result

@app.get("/api/scheduler/jobs")
async def list_scheduled_jobs(request: Request):
    """List all scheduled playbook jobs."""
    jobs = request.app.state.scheduler.scheduler.get_jobs()
    return {"jobs": [{"id": j.id, "name": j.name, "next_run": str(j.next_run_time)} for j in jobs]}

@app.get("/health")
async def health():
    return {"status": "ok", "service": "AgentAI888", "ts": datetime.utcnow().isoformat()}
