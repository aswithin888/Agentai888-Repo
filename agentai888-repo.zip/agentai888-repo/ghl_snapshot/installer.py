"""
GHL Snapshot Installer
Automatically configures a new client's GHL sub-account
with all AgentAI888 settings after Snapshot install.

Run this once per new client to replace {{AGENTAI_WEBHOOK_URL}}
with the real server URL and verify everything is live.
"""
import asyncio, os, json, httpx
from loguru import logger

GHL_API_KEY     = os.getenv("GHL_API_KEY", "")
GHL_BASE_URL    = os.getenv("GHL_BASE_URL", "https://services.leadconnectorhq.com")
AGENTAI_URL     = os.getenv("APP_URL", "https://your-server.com")

HEADERS = {
    "Authorization": f"Bearer {GHL_API_KEY}",
    "Content-Type":  "application/json",
    "Version":       "2021-07-28"
}

async def install_snapshot(location_id: str, client_name: str):
    """
    Post-install configuration for a new client sub-account.
    Call this after the GHL Snapshot has been installed.
    """
    logger.info(f"🚀 Installing AgentAI888 for {client_name} ({location_id})")

    async with httpx.AsyncClient(headers=HEADERS, timeout=30) as client:

        # 1. Create custom fields
        logger.info("📋 Creating custom fields...")
        fields = [
            {"name": "Lead Score",     "dataType": "NUMBER", "parentId": location_id},
            {"name": "AI Status",      "dataType": "TEXT",   "parentId": location_id},
            {"name": "Last AI Action", "dataType": "TEXT",   "parentId": location_id},
        ]
        for field in fields:
            try:
                r = await client.post(f"{GHL_BASE_URL}/locations/{location_id}/customFields", json=field)
                if r.status_code in [200, 201]:
                    logger.info(f"  ✅ Created field: {field['name']}")
                else:
                    logger.warning(f"  ⚠️  Field may already exist: {field['name']}")
            except Exception as e:
                logger.error(f"  ❌ Field error: {e}")

        # 2. Verify workflows exist and update webhook URLs
        logger.info("⚡ Verifying workflows...")
        try:
            r = await client.get(f"{GHL_BASE_URL}/workflows/?locationId={location_id}")
            workflows = r.json().get("workflows", [])
            agentai_workflows = [w for w in workflows if "AgentAI888" in w.get("name", "")]
            logger.info(f"  Found {len(agentai_workflows)} AgentAI888 workflows")
        except Exception as e:
            logger.error(f"  ❌ Workflow fetch error: {e}")

        # 3. Add required tags
        logger.info("🏷️  Adding system tags...")
        required_tags = ["ai-outreach","ai-followup","ai-book","ai-crm","ai-complete","needs-review","needs-human","hot-lead"]
        for tag in required_tags:
            try:
                await client.post(f"{GHL_BASE_URL}/locations/{location_id}/tags", json={"name": tag})
            except Exception:
                pass
        logger.info(f"  ✅ {len(required_tags)} tags configured")

        # 4. Create the main pipeline
        logger.info("📊 Creating AgentAI888 pipeline...")
        pipeline_data = {
            "name": f"{client_name} — AgentAI888 Pipeline",
            "locationId": location_id,
            "stages": [
                {"name": "New Lead"},
                {"name": "Contacted"},
                {"name": "Qualified"},
                {"name": "Appt Booked"},
                {"name": "Closed Won"},
                {"name": "Closed Lost"},
            ]
        }
        try:
            r = await client.post(f"{GHL_BASE_URL}/opportunities/pipelines", json=pipeline_data)
            if r.status_code in [200, 201]:
                logger.info("  ✅ Pipeline created")
            else:
                logger.warning("  ⚠️  Pipeline may already exist")
        except Exception as e:
            logger.error(f"  ❌ Pipeline error: {e}")

        # 5. Test webhook connectivity
        logger.info("🔔 Testing webhook connectivity...")
        try:
            test_payload = {
                "contact_id": "test-install",
                "name":       client_name,
                "email":      "test@install.com",
                "phone":      "0000000000",
                "tags":       [],
                "pipeline_stage": "New Lead",
                "source":     "snapshot-install"
            }
            r = await httpx.AsyncClient().post(
                f"{AGENTAI_URL}/webhooks/ghl/lead-created",
                json=test_payload,
                timeout=10
            )
            if r.status_code == 200:
                logger.info("  ✅ AgentAI888 server responding")
            else:
                logger.warning(f"  ⚠️  Server returned {r.status_code}")
        except Exception as e:
            logger.error(f"  ❌ Webhook test failed: {e} — check AGENTAI_URL")

    logger.info(f"✅ AgentAI888 installation complete for {client_name}")
    logger.info(f"   Dashboard: {AGENTAI_URL}")
    logger.info(f"   Webhook:   {AGENTAI_URL}/webhooks/ghl/lead-created")

if __name__ == "__main__":
    import sys
    location_id = sys.argv[1] if len(sys.argv) > 1 else os.getenv("GHL_LOCATION_ID", "")
    client_name = sys.argv[2] if len(sys.argv) > 2 else "New Client"
    if not location_id:
        print("Usage: python ghl_snapshot/installer.py [location_id] [client_name]")
        sys.exit(1)
    asyncio.run(install_snapshot(location_id, client_name))
