"""
SMS Interface — Command the Browser Agent by text message via Twilio.
Text a command from your phone → Browser Agent executes it in GHL.
Text a playbook name → runs the pre-built playbook.
"""
from fastapi import Request
from loguru import logger
import os

from playbooks.playbook_library import PLAYBOOKS, build_instruction, list_playbooks

ALLOWED_NUMBERS = os.getenv("ALLOWED_PHONE_NUMBERS", "").split(",")

HELP_TEXT = """AgentAI888 Commands:
LIST — show all playbooks
RUN [name] — run a playbook
DO [task] — custom GHL task
FUNNEL [description] — build industry funnel
STATUS — system status
HELP — this message

Example funnel commands:
FUNNEL roofing leads Houston
FUNNEL med spa botox consultation
FUNNEL real estate seller leads"""

class SMSInterface:
    def __init__(self, browser_agent, hitl_manager, aionexus):
        self.browser  = browser_agent
        self.hitl     = hitl_manager
        self.aionexus = aionexus

    async def handle_incoming(self, request: Request) -> str:
        """Process an incoming Twilio SMS and route to Browser Agent."""
        form = await request.form()
        from_number = form.get("From", "").strip()
        body        = form.get("Body", "").strip()

        logger.info(f"📱 SMS from {from_number}: {body[:80]}")

        # Security — only accept from authorized numbers
        if ALLOWED_NUMBERS and from_number not in ALLOWED_NUMBERS:
            logger.warning(f"⚠️  Unauthorized SMS from {from_number}")
            return self._twiml("Unauthorized number.")

        body_upper = body.upper().strip()

        # HELP
        if body_upper in ["HELP", "?"]:
            return self._twiml(HELP_TEXT)

        # STATUS
        if body_upper == "STATUS":
            return self._twiml("✅ AgentAI888 Online\n🤖 6 agents active\n🖥️ Browser Agent ready\n⏰ Scheduler running")

        # LIST playbooks
        if body_upper == "LIST":
            books = list_playbooks()
            lines = ["Available Playbooks:"] + [f"• {pb['key']}: {pb['name']}" for pb in books]
            return self._twiml("\n".join(lines))

        # RUN [playbook_name]
        if body_upper.startswith("RUN "):
            playbook_key = body[4:].strip().lower().replace(" ", "_")
            if playbook_key in PLAYBOOKS:
                await self._execute_playbook(playbook_key, {})
                return self._twiml(f"▶️ Running playbook: {PLAYBOOKS[playbook_key]['name']}\nYou'll get a reply when it's done.")
            else:
                return self._twiml(f"Playbook '{playbook_key}' not found. Text LIST to see all playbooks.")

        # DO [custom task]
        if body_upper.startswith("DO "):
            task = body[3:].strip()
            await self._execute_custom(task)
            return self._twiml(f"🖥️ Browser Agent is on it.\nTask: {task[:100]}\nYou'll get a reply when done.")

        # FUNNEL — explicit FUNNEL command or auto-detected funnel intent
        funnel_triggers = [
            "funnel", "landing page", "opt-in", "lead capture", "lead page",
            "create a page", "build a page", "make a page", "get me leads",
            "capture leads", "generate leads"
        ]
        if body_upper.startswith("FUNNEL ") or any(t in body.lower() for t in funnel_triggers):
            funnel_command = body[7:].strip() if body_upper.startswith("FUNNEL ") else body
            await self._execute_funnel(funnel_command)
            return self._twiml(
                f"🏗️ Got it! Building your funnel now.\n"
                f"Command: {funnel_command[:80]}\n"
                f"The Browser Agent is detecting the industry, designing the blueprint, "
                f"and building it in GHL. You'll get a reply with the live URL when done."
            )

        # Default — treat entire message as a custom task
        await self._execute_custom(body)
        return self._twiml(f"🖥️ Got it. Browser Agent logging into GHL now.\nTask: {body[:100]}")

    async def _execute_playbook(self, key: str, variables: dict):
        import uuid
        task_id     = f"sms-{uuid.uuid4().hex[:8]}"
        instruction = build_instruction(key, variables)
        pb          = PLAYBOOKS[key]
        hitl_mode   = "hitl" if pb.get("requires_hitl") else "auto"
        await self.browser.execute_task(task_id=task_id, task=instruction, hitl_mode=hitl_mode, hitl_manager=self.hitl, aionexus=self.aionexus)

    async def _execute_custom(self, task: str):
        import uuid
        task_id = f"sms-custom-{uuid.uuid4().hex[:8]}"
        await self.browser.execute_task(task_id=task_id, task=task, hitl_mode="auto", hitl_manager=self.hitl, aionexus=self.aionexus)

    async def _execute_funnel(self, command: str):
        async with httpx.AsyncClient(timeout=60) as c:
            try:
                r = await c.post(
                    f"{os.getenv('APP_URL', 'http://localhost:8000')}/agents/browser/funnel",
                    json={"command": command}
                )
                data = r.json()
                if data.get("needs_clarification"):
                    # Will be handled by caller — question returned in twiml
                    pass
                else:
                    summary = data.get("summary", {})
                    industry = data.get("industry", "your industry")
                    funnel_name = data.get("funnel_name", "funnel")
                    logger.info(f"Funnel queued: {funnel_name} ({industry})")
            except Exception as e:
                logger.error(f"Funnel execute error: {e}")

    def _twiml(self, message: str) -> str:
        return f'<?xml version="1.0" encoding="UTF-8"?><Response><Message>{message}</Message></Response>'
