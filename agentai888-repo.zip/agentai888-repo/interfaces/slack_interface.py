"""
Slack Interface — Command the Browser Agent via Slack slash commands.
/ghl buy phone number 713 mortgage campaign
/ghl run daily_lead_report
/ghl do [any custom task]
/ghl list
"""
from fastapi import Request
from loguru import logger
import httpx, os

from playbooks.playbook_library import PLAYBOOKS, build_instruction, list_playbooks

SLACK_BOT_TOKEN    = os.getenv("SLACK_BOT_TOKEN", "")
SLACK_SIGNING_SECRET = os.getenv("SLACK_SIGNING_SECRET", "")

class SlackInterface:
    def __init__(self, browser_agent, hitl_manager, aionexus):
        self.browser  = browser_agent
        self.hitl     = hitl_manager
        self.aionexus = aionexus

    async def handle_slash_command(self, request: Request) -> dict:
        """Handle /ghl slash commands from Slack."""
        form    = await request.form()
        command = form.get("command", "")
        text    = form.get("text", "").strip()
        user    = form.get("user_name", "unknown")
        channel = form.get("channel_id", "")

        logger.info(f"💬 Slack command from @{user}: {command} {text[:80]}")

        text_upper = text.upper()

        # /ghl list
        if text_upper == "LIST":
            books = list_playbooks()
            lines = ["*Available Playbooks:*"] + [f"• `{pb['key']}` — {pb['name']}" for pb in books]
            return {"text": "\n".join(lines)}

        # /ghl status
        if text_upper == "STATUS":
            return {"text": "✅ *AgentAI888 Online*\n🤖 6 API agents active\n🖥️ Browser Agent ready\n⏰ Scheduler running\n🔐 AIONexus monitoring"}

        # /ghl run [playbook_key]
        if text_upper.startswith("RUN "):
            key = text[4:].strip().lower().replace(" ", "_")
            if key in PLAYBOOKS:
                await self._execute_playbook(key, {}, channel)
                return {"text": f"▶️ Running playbook: *{PLAYBOOKS[key]['name']}*\nI'll post the result here when done."}
            return {"text": f"❌ Playbook `{key}` not found. Type `/ghl list` to see all playbooks."}

        # /ghl do [custom task]
        if text_upper.startswith("DO "):
            task = text[3:].strip()
            await self._execute_custom(task, channel)
            return {"text": f"🖥️ *Browser Agent on it.*\nTask: _{task[:150]}_\nI'll post the result here."}

        # FUNNEL — explicit or auto-detected
        funnel_triggers = ["funnel","landing page","opt-in","lead capture","lead page",
                          "build a page","create a page","get me leads","generate leads"]
        if text_upper.startswith("FUNNEL ") or any(t in text.lower() for t in funnel_triggers):
            funnel_command = text[7:].strip() if text_upper.startswith("FUNNEL ") else text
            await self._execute_funnel(funnel_command, channel)
            return {
                "text": f"🏗️ *Funnel command received!*\n"
                        f"Command: _{funnel_command[:100]}_\n"
                        f"The Funnel Intelligence Engine is detecting the industry and designing the blueprint.\n"
                        f"Browser Agent will build it in GHL and post the live URL here."
            }

        # Default — full text as custom task
        if text:
            await self._execute_custom(text, channel)
            return {"text": f"🖥️ *Got it.* Browser Agent logging into GHL now.\n_{text[:150]}_"}

        return {"text": "Usage: `/ghl [list | status | run PLAYBOOK | do TASK | any instruction]`"}

    async def _execute_playbook(self, key: str, variables: dict, channel: str):
        import uuid
        task_id     = f"slack-{uuid.uuid4().hex[:8]}"
        instruction = build_instruction(key, variables)
        pb          = PLAYBOOKS[key]
        hitl_mode   = "hitl" if pb.get("requires_hitl") else "auto"
        await self.browser.execute_task(task_id=task_id, task=instruction, hitl_mode=hitl_mode, hitl_manager=self.hitl, aionexus=self.aionexus)
        await self._post_to_slack(channel, f"✅ Playbook `{key}` completed.")

    async def _execute_custom(self, task: str, channel: str):
        import uuid
        task_id = f"slack-custom-{uuid.uuid4().hex[:8]}"
        await self.browser.execute_task(task_id=task_id, task=task, hitl_mode="auto", hitl_manager=self.hitl, aionexus=self.aionexus)
        await self._post_to_slack(channel, f"✅ Task complete: _{task[:100]}_")

    async def _execute_funnel(self, command: str, channel: str):
        async with httpx.AsyncClient(timeout=60) as c:
            try:
                r = await c.post(
                    f"{os.getenv('APP_URL', 'http://localhost:8000')}/agents/browser/funnel",
                    json={"command": command}
                )
                data = r.json()
                if data.get("needs_clarification"):
                    await self._post_to_slack(channel, f"❓ {data.get('question','Can you give more detail?')}")
                else:
                    summary = data.get("summary", {})
                    industry = data.get("industry", "")
                    funnel_name = data.get("funnel_name", "")
                    msg = (f"✅ *Funnel queued for {industry}*\n"
                           f"Name: `{funnel_name}`\n"
                           f"Headline: _{summary.get('headline','')}_\n"
                           f"CTA: `{summary.get('cta','')}`\n"
                           f"Fields: {summary.get('fields',0)} form fields\n"
                           f"Est. Lead Value: {summary.get('lead_value','')}\n"
                           f"Best Follow-Up: {summary.get('follow_up','')}\n"
                           f"Browser Agent is building it in GHL now...")
                    await self._post_to_slack(channel, msg)
            except Exception as e:
                logger.error(f"Slack funnel error: {e}")
                await self._post_to_slack(channel, f"❌ Funnel error: {e}")

    async def _post_to_slack(self, channel: str, message: str):
        if not SLACK_BOT_TOKEN:
            return
        async with httpx.AsyncClient() as c:
            try:
                await c.post(
                    "https://slack.com/api/chat.postMessage",
                    headers={"Authorization": f"Bearer {SLACK_BOT_TOKEN}"},
                    json={"channel": channel, "text": message},
                    timeout=10
                )
            except Exception as e:
                logger.error(f"Slack post failed: {e}")
