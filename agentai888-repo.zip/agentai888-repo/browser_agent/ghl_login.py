"""
GHL Login Handler — logs the Browser Agent into GoHighLevel.
Handles email/password + optional 2FA via TOTP.
"""
import os, asyncio
from loguru import logger

try:
    import pyotp
    HAS_TOTP = True
except ImportError:
    HAS_TOTP = False

GHL_URL     = "https://app.gohighlevel.com"
GHL_EMAIL   = os.getenv("GHL_EMAIL", "")
GHL_PASS    = os.getenv("GHL_PASSWORD", "")
GHL_2FA     = os.getenv("GHL_2FA_SECRET", "")

class GHLLogin:
    def __init__(self, page):
        self.page = page

    async def login(self):
        """Navigate to GHL and log in."""
        logger.info("🔐 Navigating to GoHighLevel login...")
        await self.page.goto(GHL_URL, wait_until="networkidle")
        await asyncio.sleep(1.5)

        # Fill email
        await self.page.fill('input[type="email"]', GHL_EMAIL)
        await asyncio.sleep(0.3)

        # Fill password
        await self.page.fill('input[type="password"]', GHL_PASS)
        await asyncio.sleep(0.3)

        # Submit
        await self.page.keyboard.press("Enter")
        await asyncio.sleep(2.5)

        # Handle 2FA if required
        if await self._needs_2fa():
            await self._handle_2fa()

        # Verify login success
        try:
            await self.page.wait_for_url("**/dashboard**", timeout=10000)
            logger.info("✅ GHL login successful")
        except Exception:
            try:
                await self.page.wait_for_url("**app.gohighlevel.com/**", timeout=5000)
                logger.info("✅ GHL login successful (alternate URL)")
            except Exception as e:
                logger.error(f"❌ GHL login may have failed: {e}")

    async def _needs_2fa(self) -> bool:
        """Check if a 2FA prompt appeared."""
        try:
            await self.page.wait_for_selector(
                'input[placeholder*="code"], input[placeholder*="verification"], input[placeholder*="OTP"]',
                timeout=3000
            )
            return True
        except Exception:
            return False

    async def _handle_2fa(self):
        """Generate and enter the TOTP code."""
        if not HAS_TOTP or not GHL_2FA:
            logger.error("❌ 2FA required but pyotp not installed or GHL_2FA_SECRET not set")
            raise RuntimeError("2FA required — install pyotp and set GHL_2FA_SECRET")

        totp = pyotp.TOTP(GHL_2FA)
        code = totp.now()
        logger.info(f"🔑 Entering 2FA code")

        await self.page.fill(
            'input[placeholder*="code"], input[placeholder*="verification"], input[placeholder*="OTP"]',
            code
        )
        await self.page.keyboard.press("Enter")
        await asyncio.sleep(2)
        logger.info("✅ 2FA code entered")
