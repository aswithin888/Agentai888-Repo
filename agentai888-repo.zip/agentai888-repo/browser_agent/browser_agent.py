"""
Browser Agent — Playwright + Claude Computer-Use
Operates GoHighLevel exactly like a human operator.
The Alleges Group Inc.
"""
import asyncio, base64, os, json
from datetime import datetime
from loguru import logger
from playwright.async_api import async_playwright, Browser, Page
import anthropic

from browser_agent.ghl_login import GHLLogin
from browser_agent.hitl import HITLManager

# Actions that require HITL approval before executing
DESTRUCTIVE_KEYWORDS = [
    "delete", "remove", "clear", "reset", "archive",
    "disable", "turn off", "unpublish", "cancel", "terminate"
]

# Maximum steps before giving up
MAX_STEPS = 40

class BrowserAgent:
    def __init__(self):
        self.client     = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
        self.playwright = None
        self.browser: Browser | None = None
        self._tasks: dict = {}
        logger.info("🖥️  Browser Agent initialized")

    async def _get_browser(self) -> Browser:
        if not self.playwright:
            self.playwright = await async_playwright().start()
        if not self.browser or not self.browser.is_connected():
            self.browser = await self.playwright.chromium.launch(
                headless=True,
                args=["--no-sandbox", "--disable-dev-shm-usage"]
            )
        return self.browser

    async def _screenshot_b64(self, page: Page) -> str:
        """Take a screenshot and return as base64."""
        screenshot = await page.screenshot(full_page=False)
        return base64.standard_b64encode(screenshot).decode("utf-8")

    def _is_destructive(self, task: str) -> bool:
        task_lower = task.lower()
        return any(kw in task_lower for kw in DESTRUCTIVE_KEYWORDS)

    async def execute_task(
        self,
        task_id: str,
        task: str,
        hitl_mode: str,
        hitl_manager: HITLManager,
        aionexus
    ):
        """
        Main browser agent loop.
        1. Log into GHL
        2. Send screenshot + task to Claude
        3. Execute Claude's action via Playwright
        4. Repeat until complete or max steps reached
        """
        self._tasks[task_id] = {"status": "running", "steps": 0, "log": [], "started": datetime.utcnow().isoformat()}
        logger.info(f"🖥️  [{task_id}] Starting: {task[:60]}")

        # HITL check before starting destructive tasks
        if hitl_mode == "always" or (hitl_mode == "auto" and self._is_destructive(task)):
            logger.info(f"🔐 [{task_id}] HITL required — waiting for approval")
            approved = await hitl_manager.request_approval(
                hitl_id=task_id,
                action=f"Browser Agent Task: {task[:120]}",
                detail=f"Task ID: {task_id}\nMode: {hitl_mode}\nStarted: {datetime.utcnow().isoformat()}"
            )
            if not approved:
                self._tasks[task_id]["status"] = "rejected"
                logger.info(f"❌ [{task_id}] HITL rejected by human")
                return

        browser = await self._get_browser()
        context = await browser.new_context(viewport={"width": 1280, "height": 800})
        page    = await context.new_page()

        try:
            # Log into GHL
            login = GHLLogin(page)
            await login.login()
            logger.info(f"✅ [{task_id}] Logged into GHL")
            self._tasks[task_id]["log"].append("Logged into GoHighLevel")

            # Build initial message for Claude
            messages = [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": f"""You are operating GoHighLevel (a CRM platform) on behalf of The Alleges Group Inc.

TASK: {task}

Instructions:
- Navigate the GHL interface to complete this task
- Use the screenshot to understand the current state of the screen
- Take precise actions — click, type, scroll as needed
- When the task is fully complete, respond with ONLY the text: TASK_COMPLETE
- If you encounter an error you cannot recover from, respond with: TASK_ERROR: [description]
- Do not ask clarifying questions — make reasonable decisions and proceed"""
                        },
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": "image/png",
                                "data": await self._screenshot_b64(page)
                            }
                        }
                    ]
                }
            ]

            step = 0
            while step < MAX_STEPS:
                step += 1
                self._tasks[task_id]["steps"] = step

                # Call Claude computer-use
                response = self.client.beta.messages.create(
                    model="claude-opus-4-5",
                    max_tokens=1024,
                    tools=[{
                        "type": "computer_20241022",
                        "name": "computer",
                        "display_width_px": 1280,
                        "display_height_px": 800,
                        "display_number": 1,
                    }],
                    messages=messages,
                    betas=["computer-use-2024-10-22"]
                )

                # Check for completion
                text_blocks = [b for b in response.content if hasattr(b, "text")]
                for block in text_blocks:
                    if "TASK_COMPLETE" in block.text:
                        self._tasks[task_id]["status"] = "complete"
                        self._tasks[task_id]["completed"] = datetime.utcnow().isoformat()
                        logger.info(f"✅ [{task_id}] Task complete in {step} steps")
                        self._tasks[task_id]["log"].append(f"Task completed successfully in {step} steps")
                        await aionexus.log(agent_id="browser", action=f"Task Complete: {task[:60]}", contact_id="browser-task", result="OK")
                        await context.close()
                        return
                    elif "TASK_ERROR" in block.text:
                        raise RuntimeError(block.text)

                # Execute tool calls
                tool_calls = [b for b in response.content if b.type == "tool_use"]
                if not tool_calls:
                    await asyncio.sleep(1)
                    continue

                tool_results = []
                for tool_call in tool_calls:
                    action = tool_call.input
                    action_type = action.get("action")
                    self._tasks[task_id]["log"].append(f"Step {step}: {action_type}")

                    if action_type == "screenshot":
                        screenshot_b64 = await self._screenshot_b64(page)
                        tool_results.append({
                            "type": "tool_result",
                            "tool_use_id": tool_call.id,
                            "content": [{"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": screenshot_b64}}]
                        })

                    elif action_type == "left_click":
                        x, y = action["coordinate"]
                        await page.mouse.click(x, y)
                        await asyncio.sleep(0.5)
                        screenshot_b64 = await self._screenshot_b64(page)
                        tool_results.append({
                            "type": "tool_result",
                            "tool_use_id": tool_call.id,
                            "content": [{"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": screenshot_b64}}]
                        })

                    elif action_type == "type":
                        await page.keyboard.type(action["text"])
                        await asyncio.sleep(0.3)
                        tool_results.append({"type": "tool_result", "tool_use_id": tool_call.id, "content": "Typed successfully"})

                    elif action_type == "key":
                        await page.keyboard.press(action["key"])
                        await asyncio.sleep(0.3)
                        tool_results.append({"type": "tool_result", "tool_use_id": tool_call.id, "content": "Key pressed"})

                    elif action_type == "scroll":
                        x, y = action["coordinate"]
                        delta = action.get("scroll_direction", "down")
                        amount = action.get("scroll_distance", 3)
                        await page.mouse.wheel(0, amount * 100 if delta == "down" else -amount * 100)
                        tool_results.append({"type": "tool_result", "tool_use_id": tool_call.id, "content": "Scrolled"})

                    elif action_type == "double_click":
                        x, y = action["coordinate"]
                        await page.mouse.dblclick(x, y)
                        tool_results.append({"type": "tool_result", "tool_use_id": tool_call.id, "content": "Double clicked"})

                    elif action_type == "right_click":
                        x, y = action["coordinate"]
                        await page.mouse.click(x, y, button="right")
                        tool_results.append({"type": "tool_result", "tool_use_id": tool_call.id, "content": "Right clicked"})

                # Add assistant response + tool results to messages
                messages.append({"role": "assistant", "content": response.content})
                messages.append({"role": "user", "content": tool_results})

                await asyncio.sleep(0.8)  # Pace between steps

            # Hit max steps
            self._tasks[task_id]["status"] = "timeout"
            logger.warning(f"⏰ [{task_id}] Hit max steps ({MAX_STEPS})")

        except Exception as e:
            logger.error(f"❌ [{task_id}] Error: {e}")
            self._tasks[task_id]["status"] = "error"
            self._tasks[task_id]["error"] = str(e)
            await aionexus.log(agent_id="browser", action="Task Error", contact_id="browser-task", result=f"ERROR: {e}")
        finally:
            await context.close()

    async def get_task_status(self, task_id: str) -> dict:
        return self._tasks.get(task_id, {"status": "not_found"})

    async def close(self):
        if self.browser:
            await self.browser.close()
        if self.playwright:
            await self.playwright.stop()
