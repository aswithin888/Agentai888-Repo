"""
HITL Manager — Human-in-the-Loop gate for Browser Agent.
Sends Slack notifications with approve/reject links.
Waits for human response before allowing destructive actions.
"""
import asyncio, os, uuid
from datetime import datetime
from loguru import logger
import httpx

SLACK_WEBHOOK  = os.getenv("SLACK_WEBHOOK_URL", "")
APPROVE_URL    = os.getenv("HITL_APPROVE_URL", "http://localhost:8000/agents/browser/hitl/approve")
REJECT_URL     = os.getenv("HITL_REJECT_URL",  "http://localhost:8000/agents/browser/hitl/reject")
TIMEOUT_MINS   = int(os.getenv("HITL_TIMEOUT_MINUTES", "30"))

class HITLManager:
    def __init__(self):
        self._pending: dict[str, asyncio.Event] = {}
        self._decisions: dict[str, bool] = {}
        self._queue: list[dict] = []

    async def request_approval(self, hitl_id: str, action: str, detail: str) -> bool:
        """
        Send HITL request to human. Wait for approve/reject.
        Returns True if approved, False if rejected or timed out.
        """
        event = asyncio.Event()
        self._pending[hitl_id] = event
        self._queue.append({
            "id":      hitl_id,
            "action":  action,
            "detail":  detail,
            "ts":      datetime.utcnow().isoformat(),
            "status":  "pending"
        })

        # Send Slack notification
        if SLACK_WEBHOOK:
            await self._notify_slack(hitl_id, action, detail)
        else:
            logger.warning("⚠️  SLACK_WEBHOOK_URL not set — HITL notification not sent")
            logger.info(f"📋 HITL pending: {hitl_id} — {action}")

        # Wait for human decision with timeout
        try:
            await asyncio.wait_for(event.wait(), timeout=TIMEOUT_MINS * 60)
        except asyncio.TimeoutError:
            logger.warning(f"⏰ HITL {hitl_id} timed out after {TIMEOUT_MINS} minutes")
            self._cleanup(hitl_id)
            return False

        approved = self._decisions.get(hitl_id, False)
        self._cleanup(hitl_id)
        return approved

    async def approve(self, hitl_id: str) -> str:
        if hitl_id in self._pending:
            self._decisions[hitl_id] = True
            self._pending[hitl_id].set()
            self._update_queue_status(hitl_id, "approved")
            logger.info(f"✅ HITL {hitl_id} approved")
            return "approved"
        return "not_found"

    async def reject(self, hitl_id: str) -> str:
        if hitl_id in self._pending:
            self._decisions[hitl_id] = False
            self._pending[hitl_id].set()
            self._update_queue_status(hitl_id, "rejected")
            logger.info(f"❌ HITL {hitl_id} rejected")
            return "rejected"
        return "not_found"

    async def get_queue(self) -> list:
        return [item for item in self._queue if item["status"] == "pending"]

    def _cleanup(self, hitl_id: str):
        self._pending.pop(hitl_id, None)
        self._decisions.pop(hitl_id, None)

    def _update_queue_status(self, hitl_id: str, status: str):
        for item in self._queue:
            if item["id"] == hitl_id:
                item["status"] = status
                break

    async def _notify_slack(self, hitl_id: str, action: str, detail: str):
        """Send a Slack message with approve/reject links."""
        message = {
            "text": "🖥️ *Browser Agent — HITL Approval Required*",
            "blocks": [
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": f"*🖥️ Browser Agent — Human Approval Required*\n\n*Action:* {action}\n*Detail:* {detail}\n*HITL ID:* `{hitl_id}`\n*Time:* {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC"
                    }
                },
                {
                    "type": "actions",
                    "elements": [
                        {
                            "type": "button",
                            "text": {"type": "plain_text", "text": "✅ Approve"},
                            "style": "primary",
                            "url": f"{APPROVE_URL}/{hitl_id}"
                        },
                        {
                            "type": "button",
                            "text": {"type": "plain_text", "text": "❌ Reject"},
                            "style": "danger",
                            "url": f"{REJECT_URL}/{hitl_id}"
                        }
                    ]
                }
            ]
        }

        try:
            async with httpx.AsyncClient() as client:
                resp = await client.post(SLACK_WEBHOOK, json=message, timeout=10)
                if resp.status_code == 200:
                    logger.info(f"📨 HITL Slack notification sent for {hitl_id}")
                else:
                    logger.warning(f"⚠️  Slack notification failed: {resp.status_code}")
        except Exception as e:
            logger.error(f"❌ Slack notification error: {e}")
