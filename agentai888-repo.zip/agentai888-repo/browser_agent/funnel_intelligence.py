"""
Funnel Intelligence Engine — Full Rewrite
Understands ANY plain-English command, figures out the industry,
and generates a complete funnel blueprint the Browser Agent builds in GHL.

Your brother can say ANYTHING. Examples:
  "make me a funnel for my tree trimming business"
  "I need something for selling solar to homeowners in Texas"
  "build a page that gets me roofing leads"
  "network marketing funnel for health products"
  "I want to get more clients for my law firm"
  "dentist funnel with before and after photos"
  "something for my food truck"

The engine figures out the rest.
The Alleges Group Inc.
"""
import os, json, re
from anthropic import Anthropic

client = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))


async def understand_command(raw_command: str) -> dict:
    """Parse any command and extract the funnel intent."""
    prompt = f"""You are reading a command from a business owner who wants a marketing funnel.
The command might be vague, casual, use slang, or be incomplete.

Command: "{raw_command}"

Return ONLY valid JSON no markdown:
{{
  "industry": "specific industry or business type",
  "industry_category": "one of: home_services, medical, legal, financial, real_estate, fitness, food, automotive, retail, education, technology, professional_services, network_marketing, other",
  "business_type": "more specific description",
  "goal": "what funnel should achieve",
  "target_customer": "who the ideal customer is",
  "key_pain_point": "main problem this business solves",
  "offer": "what they are offering",
  "urgency_hook": "why act NOW",
  "confidence": "high, medium, or low",
  "clarification_needed": false
}}"""

    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=600,
        messages=[{"role": "user", "content": prompt}]
    )
    raw = re.sub(r"^```(?:json)?\s*", "", response.content[0].text.strip())
    raw = re.sub(r"\s*```$", "", raw)
    try:
        return json.loads(raw)
    except Exception:
        return {"industry": "General Business", "industry_category": "professional_services",
                "business_type": raw_command, "goal": "generate leads",
                "target_customer": "local customers", "key_pain_point": "finding reliable services",
                "offer": "free consultation", "urgency_hook": "limited availability",
                "confidence": "low", "clarification_needed": False}


async def generate_blueprint(intent: dict, raw_command: str) -> dict:
    """Generate a complete industry-specific funnel blueprint."""
    prompt = f"""You are a world-class funnel designer and conversion copywriter.

Design a high-converting GoHighLevel lead capture funnel:
Industry: {intent['industry']}
Business Type: {intent['business_type']}
Goal: {intent['goal']}
Target Customer: {intent['target_customer']}
Key Pain Point: {intent['key_pain_point']}
Offer: {intent['offer']}
Urgency: {intent['urgency_hook']}
Original Command: "{raw_command}"

Return ONLY valid JSON no markdown. Be HYPER-SPECIFIC to this industry:
{{
  "funnel_name": "short GHL internal name",
  "page_title": "SEO browser tab title",
  "optin_page": {{
    "headline": "powerful emotional headline under 10 words",
    "subheadline": "explains value and urgency under 20 words",
    "hero_image_description": "ideal hero image for this industry",
    "cta_button_text": "action verb plus benefit 2-4 words",
    "below_cta_text": "trust or urgency line",
    "form_fields": [
      {{"label": "First Name", "type": "text", "placeholder": "Your first name", "required": true}},
      {{"label": "Phone Number", "type": "phone", "placeholder": "Best number to reach you", "required": true}},
      {{"label": "Email Address", "type": "email", "placeholder": "Your email", "required": true}}
    ],
    "trust_badges": ["badge 1", "badge 2", "badge 3", "badge 4"],
    "social_proof": "short testimonial or stat"
  }},
  "thank_you_page": {{
    "headline": "confirmation headline",
    "message": "what happens next 2 sentences",
    "next_step": "one clear action"
  }},
  "design": {{
    "primary_color": "hex emotionally right for this industry",
    "secondary_color": "hex",
    "background_color": "hex",
    "font_style": "professional friendly bold minimal luxury etc",
    "design_notes": "specific design guidance"
  }},
  "sms_autoresponse": "SMS sent within 60 seconds under 160 chars use {{first_name}}",
  "email_subject": "follow-up email subject",
  "email_body": "follow-up email 3-4 sentences",
  "workflow_tags": ["ai-outreach"],
  "industry_insights": {{
    "avg_lead_value": "estimated value of one converted lead",
    "close_rate_benchmark": "typical close rate",
    "best_follow_up_timing": "optimal call time after submit",
    "key_objections": ["objection 1", "objection 2"],
    "winning_hook": "most powerful thing to emphasize"
  }}
}}

CRITICAL: The form_fields array MUST include industry-specific fields beyond the basics.
Examples by industry:
- Roofing/Contractor: add damage type, roof age, insurance claim yes/no, property type
- Real Estate: add property address, estimated value, buying or selling or both, timeline
- Med Spa: add primary concern from wrinkles/volume/skin/body, specific treatment interest
- Legal: add case type, incident date, at fault party, have you seen a doctor
- Solar: add monthly electric bill, own or rent, roof type, shading issues
- Dental: add primary concern, last dental visit, insurance carrier
- Fitness: add primary goal, current activity level, biggest obstacle, timeline
- Coaching: add current revenue or situation, biggest challenge, timeline to results
- Insurance: add coverage type needed, current provider, age range, coverage amount needed
- Medical Courier: add facility type, daily pickup volume, current provider, STAT needed
- Network Marketing: add current income, hours available per week, previous MLM experience"""

    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=3000,
        messages=[{"role": "user", "content": prompt}]
    )
    raw = re.sub(r"^```(?:json)?\s*", "", response.content[0].text.strip())
    raw = re.sub(r"\s*```$", "", raw)
    try:
        return json.loads(raw)
    except Exception:
        return _fallback_blueprint(intent)


def build_browser_instruction(blueprint: dict, intent: dict) -> str:
    """Convert blueprint into precise GHL navigation steps for the Browser Agent."""
    optin    = blueprint.get("optin_page", {})
    thankyou = blueprint.get("thank_you_page", {})
    design   = blueprint.get("design", {})

    fields_text = ""
    for i, f in enumerate(optin.get("form_fields", []), 1):
        req = "REQUIRED" if f.get("required") else "optional"
        fields_text += f"\n   Field {i}: {f['label']} | Type: {f['type']} | Placeholder: {f.get('placeholder','')} | {req}"

    badges_text = "\n".join([f"   - {b}" for b in optin.get("trust_badges", [])])
    insights    = blueprint.get("industry_insights", {})

    return f"""Build a complete high-converting marketing funnel in GoHighLevel.

INDUSTRY: {intent.get('industry','Business')}
FUNNEL NAME: {blueprint.get('funnel_name','Lead Capture Funnel')}
GOAL: {intent.get('goal','Generate qualified leads')}

═══ STEP 1 — CREATE THE FUNNEL ═══
1. Click 'Sites' in the left GHL sidebar
2. Click 'Funnels'
3. Click '+ New Funnel' (top right area)
4. Enter funnel name: {blueprint.get('funnel_name','Lead Capture Funnel')}
5. Select the simplest Lead Generation or Opt-In template
6. Click Create Funnel

═══ STEP 2 — OPT-IN PAGE ═══
Click the first page to open the editor.

HEADLINE — find the main headline (largest text) and replace it with:
{optin.get('headline','Get Your Free Consultation')}

SUBHEADLINE — find the subheadline below the main headline and replace with:
{optin.get('subheadline','Our team will reach out within 60 seconds')}

FORM — click the form element, remove existing fields, add these in order:{fields_text}

CTA BUTTON — click the submit button and:
  - Change text to: {optin.get('cta_button_text','Get Started Now')}
  - Change background color to: {design.get('primary_color','#2563EB')}

BELOW BUTTON — add small text below the button:
{optin.get('below_cta_text','Free. No obligation.')}

TRUST BADGES — add a trust section with these badges:
{badges_text}

SOCIAL PROOF — add near the bottom:
{optin.get('social_proof','Trusted by hundreds of satisfied clients')}

COLORS:
  - Primary: {design.get('primary_color','#2563EB')}
  - Background: {design.get('background_color','#FFFFFF')}
  - Design notes: {design.get('design_notes','Clean professional layout')}

Click SAVE.

═══ STEP 3 — THANK YOU PAGE ═══
Click the Thank You page.
  - Headline: {thankyou.get('headline',"You're all set!")}
  - Body: {thankyou.get('message','We will reach out within 60 seconds.')}
  - Next step text: {thankyou.get('next_step','Watch your phone and email.')}
Click SAVE.

═══ STEP 4 — PUBLISH ═══
1. Return to funnel overview
2. Click Publish
3. Copy the published URL

═══ STEP 5 — REPORT BACK ═══
Report this exact format:
FUNNEL BUILT:
  Industry: {intent.get('industry')}
  Name: {blueprint.get('funnel_name')}
  Headline: {optin.get('headline')}
  CTA: {optin.get('cta_button_text')}
  Form Fields: {len(optin.get('form_fields',[]))}
  Lead Value: {insights.get('avg_lead_value','Unknown')}
  Best Follow-Up: {insights.get('best_follow_up_timing','Within 5 minutes')}
  URL: [paste the published funnel URL]

If you hit any error, describe what you see and continue. Do not stop."""


async def process_funnel_command(raw_command: str) -> dict:
    """
    Full pipeline — call this with anything your brother says.
    Returns everything the server needs to brief the Browser Agent.
    """
    intent = await understand_command(raw_command)

    if intent.get("clarification_needed"):
        return {
            "status": "needs_clarification",
            "clarification_question": intent.get("clarification_question", "Can you give me a bit more detail about what type of funnel you need?"),
            "intent": intent,
            "blueprint": None,
            "browser_instruction": None
        }

    blueprint           = await generate_blueprint(intent, raw_command)
    browser_instruction = build_browser_instruction(blueprint, intent)

    return {
        "status":              "ready",
        "intent":              intent,
        "blueprint":           blueprint,
        "browser_instruction": browser_instruction,
        "funnel_name":         blueprint.get("funnel_name", "New Funnel"),
        "industry":            intent["industry"],
        "summary": {
            "headline":   blueprint.get("optin_page", {}).get("headline", ""),
            "cta":        blueprint.get("optin_page", {}).get("cta_button_text", ""),
            "fields":     len(blueprint.get("optin_page", {}).get("form_fields", [])),
            "sms":        blueprint.get("sms_autoresponse", ""),
            "lead_value": blueprint.get("industry_insights", {}).get("avg_lead_value", ""),
            "follow_up":  blueprint.get("industry_insights", {}).get("best_follow_up_timing", ""),
            "objections": blueprint.get("industry_insights", {}).get("key_objections", []),
            "hook":       blueprint.get("industry_insights", {}).get("winning_hook", ""),
        }
    }


# Backward compatibility
async def generate_funnel_blueprint(command: str) -> dict:
    result = await process_funnel_command(command)
    return result.get("blueprint") or _fallback_blueprint({"industry": "General Business"})

def build_browser_instruction_legacy(blueprint: dict) -> str:
    intent = {"industry": blueprint.get("funnel_name", "Business"), "goal": "generate leads"}
    return build_browser_instruction(blueprint, intent)


def _fallback_blueprint(intent: dict) -> dict:
    return {
        "funnel_name": f"{intent.get('industry','Lead')} Capture Funnel",
        "page_title":  f"{intent.get('industry','Our Business')} — Free Consultation",
        "optin_page": {
            "headline":               "Get Your Free Consultation Today",
            "subheadline":            "Our team will reach out within 60 seconds",
            "hero_image_description": "Professional service in action",
            "cta_button_text":        "Get Started Now",
            "below_cta_text":         "Free. No obligation.",
            "form_fields": [
                {"label":"First Name",    "type":"text",  "placeholder":"Your first name",        "required":True},
                {"label":"Phone Number",  "type":"phone", "placeholder":"Best number to reach you","required":True},
                {"label":"Email Address", "type":"email", "placeholder":"Your email address",      "required":True},
            ],
            "trust_badges":  ["Licensed & Insured","5-Star Rated","Free Consultation","Fast Response"],
            "social_proof":  "Trusted by hundreds of satisfied clients"
        },
        "thank_you_page": {
            "headline":  "You're all set!",
            "message":   "Check your phone — we'll text you within 60 seconds.",
            "next_step": "Watch your phone and email."
        },
        "design": {
            "primary_color":    "#2563EB",
            "secondary_color":  "#1E3A5F",
            "background_color": "#FFFFFF",
            "font_style":       "professional",
            "design_notes":     "Clean professional layout"
        },
        "sms_autoresponse": "Hi {first_name}! Thanks for reaching out. I'll contact you shortly.",
        "email_subject":    "We received your request!",
        "email_body":       "Hi {first_name}, thank you for reaching out. We will contact you shortly.",
        "workflow_tags":    ["ai-outreach"],
        "industry_insights": {
            "avg_lead_value":        "Varies",
            "close_rate_benchmark":  "20-30%",
            "best_follow_up_timing": "Within 5 minutes",
            "key_objections":        ["Price","Timing"],
            "winning_hook":          "Speed — contact them first"
        }
    }
